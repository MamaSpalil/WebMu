<?php

/**
 * Created by PhpStorm.
 * User: Profesor08
 * Date: 30.12.2014
 * Time: 0:34
 */
class WarehouseDecoder
{
  protected $rows;
  protected $colls;
  protected $hex;
  protected $start;
  protected $end;
  protected $item_length;
  protected $data;
  protected $empty_item;
  protected $skip;
  protected $type;

  protected $ware;
  # $ware_hex - full length hex code of game wareouse
  # $item_length - length of item hex string
  public function __construct($ware_hex, $item_length, $type = 0)
  {
    $this->ware = $ware_hex;
    $this->item_length = $item_length;
    $this->type = $type;
  }

  protected function select($type)
  {
    if ($type == 'expanded')
    {
      $this->init(15, 8, 120 * $this->item_length, 120 * $this->item_length);
      $this->organize_data();
    }
    else
    {
      $this->init(15, 8, 0, 120 * $this->item_length);
      $this->organize_data();
    }
  }

  public function init($rows, $colls, $start, $end)
  {
    $this->rows = $rows;
    $this->colls = $colls;
    $this->start = $start;
    $this->end = $end;
  }

  public function organize_data()
  {
    $this->skip = array_fill(0, $this->rows, array_fill(0, $this->colls, 0));
    $this->data = array();

    for ($x = 0; $x < $this->rows; $x++)
    {
      $this->data[] = array();
      for ($y = 0; $y < $this->colls; $y++)
      {
        if ($this->skip[$x][$y] == 1) continue;
        $start = $this->start + $y * $this->item_length + $x * $this->item_length * $this->colls;

        $ware_item = array_slice($this->ware, $start, $this->item_length);

        if (count($ware_item) == 0) continue;

        $item = new Item($ware_item);
        $vx = $item->getItemX();
        $vy = $item->getItemY();
        for ($k = 0; $k < $vx; $k++)
        {
          for ($l = 0; $l < $vy; $l++)
          {
            $this->skip[$x + $l][$y + $k] = 1;
          }
        }
        if ($vy > 1) $rowspan = "rowspan='" . $vy . "'";
        else $rowspan = "";
        if ($vx > 1) $colspan = "colspan='" . $vx . "'";
        else $colspan = "";
        if ($vx < 1 || strlen($vx) == 0) $vx = 1;
        if ($vy < 1 || strlen($vy) == 0) $vy = 1;
        $this->data[$x][] = array($item, $rowspan, $colspan, $vx, $vy, $start);
      }
    }
  }

  public function find_free_space($input_item_hex, $position = -1)
  {
    $fill = array_fill(0, 15, array_fill(0, 8, 0));

    for ($x = 0; $x < 15; $x++)
    {
      for ($y = 0; $y < 8; $y++)
      {
        if ($fill[$x][$y] == 1) continue;
        $start = $this->start + $y * $this->item_length + $x * $this->item_length * 8;
        $bytes = array_slice($this->ware, $start, $this->item_length);
        if (Item::isEmpty($bytes)) continue;
        $item = new Item($bytes);

        $vx = $item->getItemX();
        $vy = $item->getItemY();

        for ($k = 0; $k < $vx; $k++)
        {
          for ($l = 0; $l < $vy; $l++)
          {
            $fill[$x + $l][$y + $k] = 1;
          }
        }
      }
    }
    $item = new Item($input_item_hex);
    $item_x = $item->getItemX();
    $item_y = $item->getItemY();

    $ok = false;
    for ($a = 0; $a < 15 && !$ok; $a++)
    {
      for ($b = 0; $b < 8 && !$ok; $b++)
      {
        if ($position >= 0 && $position != $b * $this->item_length + $a * $this->item_length * 8)
        {
          continue;
        }
        $ok = true;
        for ($y = 0; $y < $item_y && $ok; $y++)
        {
          if (($a + $y) >= 15) $ok = false;
          for ($x = 0; $x < $item_x && $ok; $x++)
          {
            if (($b + $x) >= 8 || $fill[$a + $y][$b + $x] == 1)
            {
              $ok = false;
              continue;
            }
          }
        }
        if ($ok)
        {
          return $b * $this->item_length + $a * $this->item_length * 8;
        }
        if ($position >= 0 && !$ok)
        {
          return -1;
        }
      }
    }

    return -1;
  }

  public function warehouse()
  {
    $this->select("warehouse");

    return $this->generate();
  }

  public function expanded()
  {
    $this->select("expanded");

    return $this->generate();
  }

  private function generate()
  {
    ob_start();

    echo "<table class='game_warehouse'>";
    foreach ($this->data as $key1 => $value1)
    {
      echo "<tr>";
      foreach ($value1 as $key2 => $value2)
      {
        if (!Item::isEmpty($value2[0]->getBytes()))
        {
          $width = $value2[3] * 32;
          $height = $value2[4] * 32;
          $image = $value2[0]->getImage(site_url("images/items") . "/");
          $title = $value2[0]->getInfo(false);
          echo "<td {$value2[1]} {$value2[2]} style='width: {$width}px; height: {$height}px;' title=\"{$title}\">";
          echo "<input type='checkbox' id='item_{$value2[5]}' name='item[]' value='{$value2[5]}'>";
          echo "<label for='item_{$value2[5]}'>";
          echo "<img src='$image'>";
          echo "</label>";
        }
        else
        {
          echo "<td style='width: 32px; height: 32px;'>";
        }
        echo "</td>";
      }
      echo "</tr>";
    }
    echo "</table>";

    $result = ob_get_contents();
    ob_end_clean();

    return $result;
  }
}

