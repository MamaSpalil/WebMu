<?PHP

class Item extends ItemCore
{
  protected $level_check;

  public static $images_path = "images/items/demo/";

  protected $config;

  public static $items = null;
  public static $harmony = null;
  public static $socket = null;
  public static $ancient_data = null;
  public static $elemental = null;

  public $is_pentagram = false;
  public $is_errtel = false;

  public $data = null;

  public function normalize_bytes($bytes)
  {
    $tmp = array();
    foreach ($bytes as $byte)
    {
      $tmp[] = array_shift($bytes);
    }

    return $tmp;
  }

  public function Item($bytes)
  {

    self::$ancient_data = new Ancient();

    if (is_string($bytes))
    {
      $bytes = unpack("C*", hex2bin($bytes));
    }

    if (is_array($bytes) && !isset($bytes[0]))
    {
      $bytes = $this->normalize_bytes($bytes);
    }

    parent::__construct($bytes);
    $this->level_check = 1;

    $this->increase_damage = array(0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 5, 6, 7, 8, 9);

    if (isset(self::$items[$this->group][$this->id]))
    {
      $this->data = self::$items[$this->group][$this->id];
    }
    else
    {
      $this->data = array();
    }

    if ($this->check_pentagram())
    {
      $this->is_pentagram = true;
    }
    elseif ($this->check_errtel())
    {
      $this->is_errtel = true;
    }

  }

  public static function isEmpty($bytes)
  {


    if (is_array($bytes))
    {
      foreach ($bytes as $val)
      {
        if ($val != 255)
        {
          return false;
        }
      }
    }
    else
    {
      $len = strlen($bytes);
      if (strlen($bytes) > 0)
      {
        for ($i = 0; $i < $len; $i++)
        {
          if ($bytes[$i] != "F" && $bytes[$i] != "f")
          {
            return false;
          }
        }
      }
    }

    return true;
  }

  public function getName()
  {
    if ($this->group == 13 && $this->id == 31)
    {
      if ($this->level == 1)
      {
        $name = "Spirit of Dark Raven";
        $this->level_check = 0;
      }
      else
      {
        $name = "Spirit of Dark Horse";
        $this->level_check = 0;
      }
    }
    elseif ($this->group == 12 && $this->id == 26)
    {
      switch ($this->level)
      {
        case 1:
          $name = "Red Crystal";
          break;
        case 2:
          $name = "Blue Crystal";
          break;
        case 3:
          $name = "Dark Crystal";
          break;
        case 4:
          $name = "Box of Treasure";
          break;
        case 5:
          $name = "Box of Surprice";
          break;
      }
      $this->level_check = 0;
    }
    elseif ($this->group == 13 && $this->id == 20)
    {
      if ($this->level == 1 || $this->level == 2)
      {
        $name = "Ring Of Warrior";
        switch ($this->level)
        {
          case 1 :
            $name .= " lvl 40";
            break;
          case 2 :
            $name .= " lvl 80";
            break;
        }
        $this->level_check = 0;
      }
    }
    elseif ($this->group == 14 && $this->id == 11)
    {
      switch ($this->level)
      {
        case 1:
          $name = "Star";
          break;
        case 2:
          $name = "FireCracker";
          break;
        case 3:
          $name = "Heart of Love";
          break;
        case 5:
          $name = "Silver Medal";
          break;
        case 6:
          $name = "Gold Medal";
          break;
        case 7:
          $name = "Box of Heaven";
          break;
        case 8:
          $name = "Box of Kundun +1";
          break;
        case 9:
          $name = "Box of Kundun +2";
          break;
        case 10:
          $name = "Box of Kundun +3";
          break;
        case 11:
          $name = "Box of Kundun +4";
          break;
        case 12:
          $name = "Box of Kundun +5";
          break;
        case 13:
          $name = "Heart Of Lord";
          break;
      }
      $this->level_check = 0;
    }
    elseif ($this->group == 12 && $this->id == 11)
    {
      switch ($this->level)
      {
        case 0 or "":
          $name = "Summoning Goblin";
          break;
        case 1:
          $name = "Summoning Stone Golim";
          break;
        case 2:
          $name = "Summoning Assasin";
          break;
        case 3:
          $name = "Summoning Bali";
          break;
        case 4:
          $name = "Summoning Soldier";
          break;
        case 5:
          $name = "Summoning Yeti";
          break;
        case 6:
          $name = "Summoning Dark Knight";
          break;
      }
      $this->level_check = 0;
    }
    elseif ($this->group == 12)
    {
      switch ($this->id)
      {
        case 30:
          if ($this->level == 1)
          {
            $name = "Jewel of Bless mix x20";
          }
          elseif ($this->level == 2)
          {
            $name = "Jewel of Bless mix x30";
          }
          else
          {
            $name = "Jewel of Bless mix x10";
          }
          $this->level_check = 0;
          break;
        case 31:
          if ($this->level == 1)
          {
            $name = "Jewel of Soul mix x20";
          }
          elseif ($this->level == 2)
          {
            $name = "Jewel of Soul mix x30";
          }
          else
          {
            $name = "Jewel of Soul mix x10";
          }
          $this->level_check = 0;
          break;
      }
    }
    elseif ($this->group == 13)
    {
      switch ($this->id)
      {
        case 7:
          if ($this->level == 1)
          {
            $name = "Sperman";
          }
          $this->level_check = 0;
          break;
        case 11:
          if ($this->level == 1)
          {
            $name = "Life Stone";
          }
          else
          {
            $name = "Guardian";
          }
          $this->level_check = 0;
          break;
        case 14:
          if ($this->level == 1)
          {
            $name = "Crest of Monarch";
          }
          $this->level_check = 0;
          break;
        case 16:
          $this->level_check = 1;
          break;
        case 17:
          $this->level_check = 1;
          break;
        default:
          $this->level_check = 1;
      }
    }
    elseif ($this->group == 14)
    {
      switch ($this->id)
      {
        case 7:
          if ($this->level == 1)
          {
            $name = "Potion of Soul";
          }
          $this->level_check = 0;
          break;
        case 12:
          if ($this->level == 1)
          {
            $name = "Heart";
          }
          elseif ($this->level == 2)
          {
            $name = "Pergamin";
          }
          $this->level_check = 0;
          break;
        case 21:
          if ($this->level == 1)
          {
            $name = "Stone";
          }
          elseif ($this->level == 3)
          {
            $name = "Sing of Lord";
          }
          $this->level_check = 0;
          break;
        case 32:
          if ($this->level == 1)
          {
            $name = "Pink Candy Box";
          }
          $this->level_check = 0;
          break;
        case 33:
          if ($this->level == 1)
          {
            $name = "Orange Candy Box";
          }
          $this->level_check = 0;
          break;
        case 34:
          if ($this->level == 1)
          {
            $name = "Blue Candy Box";
          }
          $this->level_check = 0;
          break;
      }
    }
    if (!isset($name))
    {
      $name = isset(self::$items[$this->group][$this->id]['Name']) ? self::$items[$this->group][$this->id]['Name'] : "Unknown Item";
    }
    $name_anc = "";
    if ($this->ancient > 0)
    {
      $name_anc = $this->getAncientName();
    }

    return trim($name_anc . " " . $name);
  }

  public function getColorizedFullName($name = "", $anc = "")
  {
    if (strlen($name) == 0)
    {
      $name = $this->getName();
    }
    $name_class = "name_normal";
    if ($this->excellent > 0 && $this->group > 11)
    {
      $name_class = "name_special";
    }
    if (($this->option > 0 || $this->luck > 0 || $this->skill > 0) && $this->group < 12)
    {
      $name_class = "name_option";
    }
    if ($this->option == 0 && $this->luck == 0 && $this->skill == 0 && $this->group < 12 && ($this->level == 3 || $this->level == 4))
    {
      $name_class = "name_lvl3";
    }
    if ($this->group == 13 && ($this->id == 16 || $this->id == 17 || $this->id == 18) && ($this->level == 3 || $this->level == 4))
    {
      $name_class = "name_lvl3";
    }
    if ($this->group == 13 && ($this->id == 16 || $this->id == 17 || $this->id == 18) && ($this->level == 5 || $this->level == 6))
    {
      $name_class = "name_option";
    }
    if ($this->group == 13 && ($this->id == 16 || $this->id == 17 || $this->id == 18) && $this->level > 6)
    {
      $name_class = "name_special";
    }
    if ($this->option == 0 && $this->luck == 0 && $this->skill == 0 && $this->group < 12 && ($this->level == 5 || $this->level == 6))
    {
      $name_class = "name_option";
    }
    if ($this->group < 12 && $this->level >= 7)
    {
      $name_class = "name_special";
    }
    $rings_pendants = array(8, 9, 12, 13, 21, 22, 23, 24, 25, 26, 27, 28);
    if ($this->excellent > 0 && (($this->group < 12) || ($this->group == 13 && in_array($this->id, $rings_pendants))))
    {
      $name_class = "name_excellent";
    }
    $jewels = array(15, 30, 31, 136, 137, 138, 139, 140, 141, 142, 143);
    if ($this->group == 12 && in_array($this->id, $jewels))
    {
      $name_class = "name_special";
    }
    $jewels = array(13, 14, 16, 22, 31, 42);
    if ($this->group == 14 && in_array($this->id, $jewels))
    {
      $name_class = "name_special";
    }
    $wings_array = array(0, 1, 2, 3, 4, 5, 6, 36, 37, 38, 39, 40, 41, 42, 43, 49, 50);
    if (($this->group == 12 && in_array($this->id, $wings_array)) || ($this->group == 13 && $this->id == 30))
    {
      $name_class = "name_special";
    }
    foreach ($this->sockets as $val)
    {
      if ($val != 255)
      {
        $name_class = "name_socket";
      }
    }
    $ancient_name = "";
    if ($this->ancient != '0')
    {
      $name_class = "name_ancient";
      if (strlen($anc) > 0)
      {
        $ancient_name = $anc . " ";
      }
    }

    $ret = "<span class='$name_class'>" . $this->getExcellentText(" ") . $ancient_name . $name . ($this->getLevel() > 0 ? " +" . $this->getLevel() : "") . "<span class='option'>" . $this->getOptionText() . "</span>
    <span class='skill'>" . ($this->getSkill() > 0 ? " +Skill" : "") . "</span>
    <span class='luck'>" . ($this->getLuck() > 0 ? " +Luck" : "") . "</span>
    <span class='pvp'>" . ($this->pvp ? " +Pvp" : "") . "</span>";

    if ($this->is_errtel || $this->is_pentagram)
    {
      switch ($this->bytes[10] % 16)
      {
        case 1:
          $ret .= "<span class='element fire'>(Fire Element)</span>";
          break;
        case 2:
          $ret .= "<span class='element water'>(Water Element)</span>";
          break;
        case 3:
          $ret .= "<span class='element earth'>(Earth Element)</span>";
          break;
        case 4:
          $ret .= "<span class='element wind'>(Wind Element)</span>";
          break;
        case 5:
          $ret .= "<span class='element darkness'>(Darkness Element)</span>";
          break;
      }

    }
    else
    {
      $ret .= "<span class='harmony'>" . ($this->getHarmonyType() > 0 ? " +Harm" : "") . "</span>";
    }

    $ret .= "</span>";

    return $ret;
  }

  public function getColorClassName()
  {
    $name_class = "name_normal";
    if ($this->excellent > 0 && $this->group > 11)
    {
      $name_class = "name_special";
    }
    if (($this->option > 0 || $this->luck > 0 || $this->skill > 0) && $this->group < 12)
    {
      $name_class = "name_option";
    }
    if ($this->option == 0 && $this->luck == 0 && $this->skill == 0 && $this->group < 12 && ($this->level == 3 || $this->level == 4))
    {
      $name_class = "name_lvl3";
    }
    if ($this->group == 13 && ($this->id == 16 || $this->id == 17 || $this->id == 18) && ($this->level == 3 || $this->level == 4))
    {
      $name_class = "name_lvl3";
    }
    if ($this->group == 13 && ($this->id == 16 || $this->id == 17 || $this->id == 18) && ($this->level == 5 || $this->level == 6))
    {
      $name_class = "name_option";
    }
    if ($this->group == 13 && ($this->id == 16 || $this->id == 17 || $this->id == 18) && $this->level > 6)
    {
      $name_class = "name_special";
    }
    if ($this->option == 0 && $this->luck == 0 && $this->skill == 0 && $this->group < 12 && ($this->level == 5 || $this->level == 6))
    {
      $name_class = "name_option";
    }
    if ($this->group < 12 && $this->level >= 7)
    {
      $name_class = "name_special";
    }
    $rings_pendants = array(8, 9, 12, 13, 21, 22, 23, 24, 25, 26, 27, 28);
    if ($this->excellent > 0 && (($this->group < 12) || ($this->group == 13 && in_array($this->id, $rings_pendants))))
    {
      $name_class = "name_excellent";
    }
    $jewels = array(15, 30, 31, 136, 137, 138, 139, 140, 141, 142, 143);
    if ($this->group == 12 && in_array($this->id, $jewels))
    {
      $name_class = "name_special";
    }
    $jewels = array(13, 14, 16, 22, 31, 42);
    if ($this->group == 14 && in_array($this->id, $jewels))
    {
      $name_class = "name_special";
    }
    $wings_array = array(0, 1, 2, 3, 4, 5, 6, 36, 37, 38, 39, 40, 41, 42, 43, 49, 50);
    if (($this->group == 12 && in_array($this->id, $wings_array)) || ($this->group == 13 && $this->id == 30))
    {
      $name_class = "name_special";
    }
    foreach ($this->sockets as $val)
    {
      if ($val != 255)
      {
        $name_class = "name_socket";
      }
    }
    if ($this->ancient != '0')
    {
      $name_class = "name_ancient";
    }

    return $name_class;
  }

  public function getColorizedShortName($name = "", $anc = "")
  {
    if (strlen($name) == 0)
    {
      $name = $this->getName();
    }
    $name_class = "name_normal";
    if ($this->excellent > 0 && $this->group > 11)
    {
      $name_class = "name_special";
    }
    if (($this->option > 0 || $this->luck > 0 || $this->skill > 0) && $this->group < 12)
    {
      $name_class = "name_option";
    }
    if ($this->option == 0 && $this->luck == 0 && $this->skill == 0 && $this->group < 12 && ($this->level == 3 || $this->level == 4))
    {
      $name_class = "name_lvl3";
    }
    if ($this->group == 13 && ($this->id == 16 || $this->id == 17 || $this->id == 18) && ($this->level == 3 || $this->level == 4))
    {
      $name_class = "name_lvl3";
    }
    if ($this->group == 13 && ($this->id == 16 || $this->id == 17 || $this->id == 18) && ($this->level == 5 || $this->level == 6))
    {
      $name_class = "name_option";
    }
    if ($this->group == 13 && ($this->id == 16 || $this->id == 17 || $this->id == 18) && $this->level > 6)
    {
      $name_class = "name_special";
    }
    if ($this->option == 0 && $this->luck == 0 && $this->skill == 0 && $this->group < 12 && ($this->level == 5 || $this->level == 6))
    {
      $name_class = "name_option";
    }
    if ($this->group < 12 && $this->level >= 7)
    {
      $name_class = "name_special";
    }
    $rings_pendants = array(8, 9, 12, 13, 21, 22, 23, 24, 25, 26, 27, 28);
    if ($this->excellent > 0 && (($this->group < 12) || ($this->group == 13 && in_array($this->id, $rings_pendants))))
    {
      $name_class = "name_excellent";
    }
    $jewels = array(15, 30, 31, 136, 137, 138, 139, 140, 141, 142, 143);
    if ($this->group == 12 && in_array($this->id, $jewels))
    {
      $name_class = "name_special";
    }
    $jewels = array(13, 14, 16, 22, 31, 42);
    if ($this->group == 14 && in_array($this->id, $jewels))
    {
      $name_class = "name_special";
    }
    $wings_array = array(0, 1, 2, 3, 4, 5, 6, 36, 37, 38, 39, 40, 41, 42, 43, 49, 50);
    if (($this->group == 12 && in_array($this->id, $wings_array)) || ($this->group == 13 && $this->id == 30))
    {
      $name_class = "name_special";
    }
    foreach ($this->sockets as $val)
    {
      if ($val != 255)
      {
        $name_class = "name_socket";
      }
    }
    $ancient_name = "";
    if ($this->ancient != '0')
    {
      $name_class = "name_ancient";
      //      if (strlen($anc) > 0) $ancient_name = $anc . " ";
    }

    if ($this->is_pentagram || $this->is_errtel)
    {
      $harmony = "";
    }
    else
    {
      $harmony = "<span class='harmony'>" . ($this->getHarmonyType() > 0 ? " +Harm" : "") . "</span>";
    }

    return "<span class='$name_class'>" . $this->getExcellentText(" ") . $ancient_name . $name . ($this->getLevel() > 0 ? " +" . $this->getLevel() : "") . "<span class='option'>" . $this->getOptionText(true) . "</span>
    <span class='skill'>" . ($this->getSkill() > 0 ? " +Skill" : "") . "</span>
    <span class='luck'>" . ($this->getLuck() > 0 ? " +Luck" : "") . "</span>
    <span class='pvp'>" . ($this->pvp ? " +Pvp" : "") . "</span>
    {$harmony}
    </span>";
  }

  public function getColorizedName($anc = "")
  {
    $name = $this->getName();
    $name_class = "name_normal";
    if ($this->excellent > 0 && $this->group > 11)
    {
      $name_class = "name_special";
    }
    if (($this->option > 0 || $this->luck > 0 || $this->skill > 0) && $this->group < 12)
    {
      $name_class = "name_option";
    }
    if ($this->option == 0 && $this->luck == 0 && $this->skill == 0 && $this->group < 12 && ($this->level == 3 || $this->level == 4))
    {
      $name_class = "name_lvl3";
    }
    if ($this->option == 0 && $this->luck == 0 && $this->skill == 0 && $this->group < 12 && ($this->level == 5 || $this->level == 6))
    {
      $name_class = "name_option";
    }
    if ($this->group < 12 && $this->level >= 7)
    {
      $name_class = "name_special";
    }
    $rings_pendants = array(8, 9, 12, 13, 21, 22, 23, 24, 25, 26, 27, 28);
    if ($this->excellent > 0 && (($this->group < 12) || ($this->group == 13 && in_array($this->id, $rings_pendants))))
    {
      $name_class = "name_excellent";
    }
    $jewels = array(15, 30, 31, 136, 137, 138, 139, 140, 141, 142, 143);
    if ($this->group == 12 && in_array($this->id, $jewels))
    {
      $name_class = "name_special";
    }
    $jewels = array(13, 14, 16, 22, 31, 42);
    if ($this->group == 14 && in_array($this->id, $jewels))
    {
      $name_class = "name_special";
    }
    $wings_array = array(0, 1, 2, 3, 4, 5, 6, 36, 37, 38, 39, 40, 41, 42, 43, 49, 50);
    if (($this->group == 12 && in_array($this->id, $wings_array)) || ($this->group == 13 && $this->id == 30))
    {
      $name_class = "name_special";
    }
    foreach ($this->sockets as $val)
    {
      if ($val != 255)
      {
        $name_class = "name_socket";
      }
    }
    $ancient_name = "";
    if ($this->ancient != '0')
    {
      $name_class = "name_ancient";
      if (strlen($anc) > 0)
      {
        $ancient_name = $anc . " ";
      }
    }

    return "<span class='$name_class'>" . $this->getExcellentText(" ") . $ancient_name . $name . ($this->getLevel() > 0 ? " +" . $this->getLevel() : "") . "</span>";
  }

  public function getExcellentText($text_after)
  {
    if ($this->excellent > 0)
    {
      if ($this->group >= 0 && $this->group <= 11)
      {
        return "Excellent" . $text_after;
      }
      $rings_pendants = array(8, 9, 12, 13, 21, 22, 23, 24, 25, 26, 27, 28);
      if ($this->group == 13 && in_array($this->id, $rings_pendants))
      {
        return "Excellent" . $text_after;
      }

      return "";
    }

    return "";
  }

  public function getExcellentOptionText($id)
  {
    //    if ($this->excellent == 0)
    //    {
    //      return "";
    //    }

    if (($this->group <= 5) || ($this->group == 13 && ($this->id == 12 || $this->id == 13 || $this->id >= 25 && $this->id <= 28)))
    {
      switch ($id)
      {
        case 1:
          return "Mana After Hunting Monsters +mana/8";
        case 2:
          return "Life After Hunting Monsters +life/8";
        case 4:
          return "Increase Attacking(Wizardy) speed +7";
        case 8:
          return "Increase Damage +2%";
        case 16:
          return "Increase Damage +Level/20";
        case 32:
          return "Excellent Damage Rate +10%";
      }
    }
    elseif (($this->group >= 6 && $this->group <= 11) || (($this->group == 13 && $this->id != 30) && (($this->id >= 8 && $this->id <= 10) || ($this->id >= 20 && $this->id <= 24) || ($this->id >= 38 && $this->id <= 41))))
    {
      switch ($id)
      {
        case 1:
          return "Increase Rate of Zen 40%";
        case 2:
          return "Defense Success Rate +10%";
        case 4:
          return "Reflect Damage +5%";
        case 8:
          return "Damage Decrease +4%";
        case 16:
          return "Increase Max Mana +4%";
        case 32:
          return "Increase Max Hp +4%";
      }
    }
    elseif ($this->group == 12 && in_array($this->id, array(0, 1, 2, 41)))
    {
      // wing lvl 1
      return false;
    }
    elseif ($this->group == 12 && in_array($this->id, array(3, 4, 5, 6, 42, 49)))
    {
      // wing lvl 2
      switch ($id)
      {
        case 1:
          return "Increase Life +125";
        case 2:
          return "Increase Mana +125";
        case 4:
          return "Chance of Damage from Breaking Enemy&#39;s Defence 5%";
        case 8:
          return "Increase Maximum AG +50";
        case 16:
          return "Increase Attack (Wizardry) Speed +5";
        case 32:
          return "[Additional (Wizardry) Damage] / HP  Recovery/ Curse";
      }
    }
    elseif ($this->group == 13 && $this->id == 30)
    {
      // cape of lord
      switch ($id)
      {
        case 1:
          return "Increase Life +125";
        case 2:
          return "Increase Mana +125";
        case 4:
          return "Chance of Damage from Breaking Enemy&#39;s Defence 5%";
        case 8:
          return "Increase Maximum AG +50";
        case 16:
          return "Increase Attack (Wizardry) Speed +5";
      }
    }
    elseif ($this->group == 12 && in_array($this->id, array(262, 263, 264, 265)))
    {
      // wings lvl 2.5
      switch ($id)
      {
        case 1:
          return "Chance of Damage from Breaking Enemy&#39;s Defence 5%";
        case 2:
          return "Chance of Fully Recovering Life 5%";
      }
    }
    elseif ($this->group == 12 && in_array($this->id, array(36, 37, 38, 39, 40, 43, 50, 266)))
    {
      // wings lvl3
      switch ($id)
      {
        case 1:
          return "Chance of Damage from Breaking Enemy&#39;s Defence 5%";
        case 2:
          return "Chance of Returning the Enemy&#39;s Attack Power 5%";
        case 4:
          return "Chance of Fully Recovering Life 5%";
        case 8:
          return "Chance of Fully Recovering Mana 5%";
        case 16:
          return "[Additional (Wizardry) Damage] / HP  Recovery/ Curse";
      }
    }
    elseif ($this->group == 12 && in_array($this->id, array(267)))
    {
      // wing of angel and devil
      switch ($id)
      {
        case 1:
          return "Chance of Double Damage 4%";
        case 2:
          return "Chance of Damage from Breaking Enemy&#39;s Defence 4%";
        case 4:
          return "Chance of Fully Recovering Life 5%";
      }
    }
    elseif ($this->group == 13 && $this->id == 37)
    {
      switch ($id)
      {
        case 1:
          return "Plazma Storm Skill: Increase final damage 10%";
        case 2:
          return "Plazma Storm Skill: Absorb final damage 10%";
        case 4:
          return "Plazma Storm Skill: Increase final damage 10%, Absorb final damage 10%";
      }
    }

    return false;
  }

  public function getExcellentOptionsText()
  {
    if ($this->excellent == 0)
    {
      return "";
    }

    if (($this->group <= 5) || ($this->group == 13 && ($this->id == 12 || $this->id == 13 || $this->id >= 25 && $this->id <= 28)))
    {
      $excellent[1] = "<div class='item_mana_recovery'>{$this->getExcellentOptionText(1)}</div>";
      $excellent[2] = "<div class='item_life_recovery'>{$this->getExcellentOptionText(2)}</div>";
      $excellent[4] = "<div class='item_increase_attacking_speed'>{$this->getExcellentOptionText(4)}</div>";
      $excellent[8] = "<div class='item_increase_damage'>{$this->getExcellentOptionText(8)}</div>";
      $excellent[16] = "<div class='item_increase_damage_lvl20'>{$this->getExcellentOptionText(16)}</div>";
      $excellent[32] = "<div class='item_excellent_damage_rate'>{$this->getExcellentOptionText(32)}</div>";
    }
    elseif (($this->group >= 6 && $this->group <= 11) || (($this->group == 13 && $this->id != 30) && (($this->id >= 8 && $this->id <= 10) || ($this->id >= 20 && $this->id <= 24) || ($this->id >= 38 && $this->id <= 41))))
    {
      $excellent[1] = "<div class='item_increase_zen_rate'>{$this->getExcellentOptionText(1)}</div>";
      $excellent[2] = "<div class='item_defence_success_rate'>{$this->getExcellentOptionText(2)}</div>";
      $excellent[4] = "<div class='item_reflect_damage'>{$this->getExcellentOptionText(4)}</div>";
      $excellent[8] = "<div class='item_damage_decrease'>{$this->getExcellentOptionText(8)}</div>";
      $excellent[16] = "<div class='item_max_mana'>{$this->getExcellentOptionText(16)}</div>";
      $excellent[32] = "<div class='item_max_life' >{$this->getExcellentOptionText(32)}</div>";
    }
    elseif ($this->group == 12 && in_array($this->id, array(36, 37, 38, 39, 40, 43, 50)))
    {
      $excellent[1] = "<div class='item_ignore_defence' >{$this->getExcellentOptionText(1)}</div>";
      $excellent[2] = "<div class='item_return_enemies_attack_power' >{$this->getExcellentOptionText(1)}</div>";
      $excellent[4] = "<div class='item_complete_recovery_of_life' >{$this->getExcellentOptionText(4)}</div>";
      $excellent[8] = "<div class='item_complete_recovery_of_mana' >{$this->getExcellentOptionText(8)}</div>";
    }
    elseif ($this->group == 12 || ($this->group == 13 && $this->id == 30))
    {
      $excellent[1] = "<div class='item_increase_life' >{$this->getExcellentOptionText(1)}</div>";
      $excellent[2] = "<div class='item_increase_mana'>{$this->getExcellentOptionText(2)}</div>";
      $excellent[4] = "<div class='item_ignore_defence'>{$this->getExcellentOptionText(4)}</div>";
      $excellent[8] = "<div class='item_max_stamina'>{$this->getExcellentOptionText(8)}</div>";
      $excellent[16] = "<div class='item_wizardry_speed'>{$this->getExcellentOptionText(16)}</div>";
    }
    elseif ($this->group == 13 && $this->id == 37)
    {
      switch ($this->excellent > 0)
      {
        case 1:
          $excellent[1] = "<div class='item_plazma_storm_increase_damage' >{$this->getExcellentOptionText(1)}</div>";
          break;
        case 2:
          $excellent[2] = "<div class='item_plazma_storm_absorb_damage' >{$this->getExcellentOptionText(2)}</div>";
          break;
        case 4:
          $excellent[4] = "<div class='item_plazma_storm_gold' >{$this->getExcellentOptionText(4)}</div>";
          break;
      }
    }
    $curexcl = $this->excellent;
    $display = "";
    for ($i = 32; $i > 0; $i /= 2)
    {
      if ($curexcl >= $i)
      {
        if (isset($excellent[$i]))
        {
          $display = $excellent[$i] . $display;
        }
        $curexcl -= $i;
      }
    }

    return $display;
  }

  public function getOptionText($type = false)
  {

    if ($this->option > 0)
    {

      if ($type)
      {
        $dmg = " Dmg";
        $wzdmg = " WzDmg";
        $defrate = " Rate";
        $def = " Def";
        $hp = " HpRec";
        $curse = " Curse";
      }
      else
      {
        $dmg = " Additional dmg";
        $wzdmg = "% Additional wizardy dmg";
        $defrate = "% Additional defence rate";
        $def = " Additional defence";
        $hp = "% HP recovery";
        $curse = " Curse";
      }

      if ($this->group <= 4)
      {
        return " +" . ($this->option * 4) . $dmg;
      }
      if ($this->group == 5)
      {
        return " +" . ($this->option * 4) . $wzdmg;
      }
      if ($this->group == 6)
      {
        return " +" . ($this->option * 5) . $defrate;
      }
      if ($this->group <= 11)
      {
        return " +" . ($this->option * 4) . $def;
      }
      if ($this->group == 12 && $this->id == 1)
      {
        return " +" . ($this->option * 4) . $wzdmg;
      } # dw
      if ($this->group == 12 && $this->id == 2)
      {
        return " +" . ($this->option * 4) . $dmg;
      } # dk
      if ($this->group == 12 && $this->id == 0)
      {
        return " +" . ($this->option) . $hp;
      } # elf
      if ($this->group == 12 && $this->id == 3 && $this->excellent >= 32)
      {
        return " +" . ($this->option) . $hp;
      } #elf
      if ($this->group == 12 && $this->id == 3)
      {
        return " +" . ($this->option * 4) . $dmg;
      } #elf
      if ($this->group == 12 && $this->id == 4 && $this->excellent >= 32)
      {
        return " +" . ($this->option * 4) . $wzdmg;
      } #dw
      if ($this->group == 12 && $this->id == 4)
      {
        return " +" . ($this->option) . $hp;
      } #dw
      if ($this->group == 12 && $this->id == 5 && $this->excellent >= 32)
      {
        return " +" . ($this->option * 4) . $dmg;
      } #dk
      if ($this->group == 12 && $this->id == 5)
      {
        return " +" . ($this->option) . $hp;
      } #dk
      if ($this->group == 12 && $this->id == 6 && $this->excellent >= 32)
      {
        return " +" . ($this->option * 4) . $dmg;
      } #mg
      if ($this->group == 12 && $this->id == 6)
      {
        return " +" . ($this->option * 4) . $wzdmg;
      } #mg
      if ($this->group == 13 && $this->id == 30)
      {
        return " +" . ($this->option * 4) . $dmg;
      } #dl
      if ($this->group == 12 && $this->id == 37 && $this->excellent >= 16)
      {
        return " +" . ($this->option * 4) . $wzdmg;
      } #3rd dw
      if ($this->group == 12 && $this->id == 43 && $this->excellent >= 16)
      {
        return " +" . ($this->option * 4) . $wzdmg;
      } #3rd sum
      $wings_3rd = array(36, 37, 38, 39, 40, 43);
      if ($this->group == 12 && in_array($this->id, $wings_3rd) && $this->excellent >= 16)
      {
        return " +" . ($this->option * 4) . $dmg;
      } #3rd
      if ($this->group == 12 && in_array($this->id, $wings_3rd))
      {
        return " +" . ($this->option) . $hp;
      } #3rd
      if ($this->group == 12 && $this->id == 41)
      {
        return " +" . ($this->option * 4) . $wzdmg;
      } #1st sum
      if ($this->group == 12 && $this->id == 42 && $this->excellent >= 32)
      {
        return " +" . ($this->option * 4) . $wzdmg;
      } #2nd sum
      if ($this->group == 12 && $this->id == 42)
      {
        return " +" . ($this->option * 4) . $curse;
      } #2nd sum
      if ($this->group <= 14)
      {
        return " +" . ($this->option) . $hp;
      }

    }

    return "";
  }

  public function getPvpText()
  {

    //    if ($this->pvp)
    //    {
    //      if (!isset($this->CI->itembase->refinery_value[$this->group][$this->id][0]))
    //      {
    //        return "No refinary description";
    //      }
    //      if (!isset($this->CI->itembase->refinery_name[$this->CI->itembase->refinery_value[$this->group][$this->id][0]]))
    //      {
    //        return "";
    //      }
    //      $return = $this->CI->itembase->refinery_name[$this->CI->itembase->refinery_value[$this->group][$this->id][0]] . " " . $this->CI->itembase->refinery_value[$this->group][$this->id][1];
    //      $return .= "<br>";
    //      if (!$this->CI->itembase->refinery_name[$this->CI->itembase->refinery_value[$this->group][$this->id][0]])
    //      {
    //        return $return;
    //      }
    //      $return .= $this->CI->itembase->refinery_name[$this->CI->itembase->refinery_value[$this->group][$this->id][2]] . " " . $this->CI->itembase->refinery_value[$this->group][$this->id][3];
    //
    //      return $return;
    //    }
    //
    //    return "";
  }

  public function getPvpOptionName()
  {

    //    if (!isset($this->CI->itembase->refinery_value[$this->group][$this->id][0]))
    //    {
    //      return "No refinary description";
    //    }
    //    if (!isset($this->CI->itembase->refinery_name[$this->CI->itembase->refinery_value[$this->group][$this->id][0]]))
    //    {
    //      return "";
    //    }
    //    $return = $this->CI->itembase->refinery_name[$this->CI->itembase->refinery_value[$this->group][$this->id][0]] . " " . $this->CI->itembase->refinery_value[$this->group][$this->id][1];
    //    $return .= "<br>";
    //    if (!$this->CI->itembase->refinery_name[$this->CI->itembase->refinery_value[$this->group][$this->id][0]])
    //    {
    //      return $return;
    //    }
    //    $return .= $this->CI->itembase->refinery_name[$this->CI->itembase->refinery_value[$this->group][$this->id][2]] . " " . $this->CI->itembase->refinery_value[$this->group][$this->id][3];
    //
    //    return $return;
  }

  private function getHarmonyOptionText($group, $opt, $hlvl)
  {
    #Index Name Weight MinLvl Lvl0  Zen0  Lvl1  Zen1  Lvl2  Zen2  Lvl3  Zen3  Lvl4  Zen4  Lvl5  Zen5  Lvl6  Zen6  Lvl7  Zen7  Lvl8  Zen8  Lvl9  Zen9  Lvl10 Zen10 Lvl11 Zen11 Lvl12 Zen12 Lvl13 Zen13
    $harmony_data[0][] = array(
      1,
      "Increases Minimum Damage",
      40,
      0,
      2,
      100000,
      3,
      110000,
      4,
      120000,
      5,
      130000,
      6,
      140000,
      7,
      150000,
      9,
      200000,
      11,
      220000,
      12,
      240000,
      14,
      280000,
      15,
      320000,
      16,
      360000,
      17,
      400000,
      20,
      500000
    );
    $harmony_data[0][] = array(
      2,
      "Increases Maximum Damage",
      40,
      0,
      3,
      100000,
      4,
      110000,
      5,
      120000,
      6,
      130000,
      7,
      140000,
      8,
      150000,
      10,
      200000,
      12,
      220000,
      14,
      240000,
      17,
      280000,
      20,
      320000,
      23,
      360000,
      26,
      400000,
      29,
      500000
    );
    $harmony_data[0][] = array(
      3,
      "Reduces Required Strength",
      40,
      0,
      6,
      100000,
      8,
      110000,
      10,
      120000,
      12,
      130000,
      14,
      140000,
      16,
      150000,
      20,
      200000,
      23,
      220000,
      26,
      240000,
      29,
      280000,
      32,
      320000,
      35,
      360000,
      37,
      400000,
      40,
      500000
    );
    $harmony_data[0][] = array(
      4,
      "Reduces Required Agility",
      40,
      0,
      6,
      100000,
      8,
      110000,
      10,
      120000,
      12,
      130000,
      14,
      140000,
      16,
      150000,
      20,
      200000,
      23,
      220000,
      26,
      240000,
      29,
      280000,
      32,
      320000,
      35,
      360000,
      37,
      400000,
      40,
      500000
    );
    $harmony_data[0][] = array(
      5,
      "Increases Min / Max Damage",
      30,
      6,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      7,
      200000,
      8,
      220000,
      9,
      240000,
      11,
      280000,
      12,
      320000,
      14,
      360000,
      16,
      400000,
      19,
      500000
    );
    $harmony_data[0][] = array(
      6,
      "Increases Critical Damage",
      30,
      6,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      12,
      200000,
      14,
      220000,
      16,
      240000,
      18,
      280000,
      20,
      320000,
      22,
      360000,
      24,
      400000,
      30,
      500000
    );
    $harmony_data[0][] = array(
      7,
      "Increases Skill Damage",
      20,
      9,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      12,
      280000,
      14,
      320000,
      16,
      360000,
      18,
      400000,
      22,
      500000
    );
    $harmony_data[0][] = array(
      8,
      "Increases Attack Success Rate (PvP)",
      20,
      9,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      5,
      280000,
      7,
      320000,
      9,
      360000,
      11,
      400000,
      14,
      500000
    );
    $harmony_data[0][] = array(
      9,
      "Increases SD Reduction",
      20,
      9,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      3,
      280000,
      5,
      320000,
      7,
      360000,
      9,
      400000,
      10,
      500000
    );
    $harmony_data[0][] = array(
      10,
      "Increases SD Ignore Rate",
      10,
      13,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      10,
      500000
    );

    $harmony_data[1][] = array(
      1,
      "Increases Wizardry",
      40,
      0,
      6,
      100000,
      8,
      110000,
      10,
      120000,
      12,
      130000,
      14,
      140000,
      16,
      150000,
      17,
      200000,
      18,
      220000,
      19,
      240000,
      21,
      280000,
      23,
      320000,
      25,
      360000,
      27,
      400000,
      31,
      500000
    );
    $harmony_data[1][] = array(
      2,
      "Reduces Required Strength",
      40,
      0,
      6,
      100000,
      8,
      110000,
      10,
      120000,
      12,
      130000,
      14,
      140000,
      16,
      150000,
      20,
      200000,
      23,
      220000,
      26,
      240000,
      29,
      280000,
      32,
      320000,
      35,
      360000,
      37,
      400000,
      40,
      500000
    );
    $harmony_data[1][] = array(
      3,
      "Reduces Required Agility",
      40,
      0,
      6,
      100000,
      8,
      110000,
      10,
      120000,
      12,
      130000,
      14,
      140000,
      16,
      150000,
      20,
      200000,
      23,
      220000,
      26,
      240000,
      29,
      280000,
      32,
      320000,
      35,
      360000,
      37,
      400000,
      40,
      500000
    );
    $harmony_data[1][] = array(
      4,
      "Increases Skill Damage",
      30,
      6,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      7,
      200000,
      10,
      220000,
      13,
      240000,
      16,
      280000,
      19,
      320000,
      22,
      360000,
      25,
      400000,
      30,
      500000
    );
    $harmony_data[1][] = array(
      5,
      "Increases Critical Damage",
      30,
      6,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      10,
      200000,
      12,
      220000,
      14,
      240000,
      16,
      280000,
      18,
      320000,
      20,
      360000,
      22,
      400000,
      28,
      500000
    );
    $harmony_data[1][] = array(
      6,
      "Increases SD Reduction",
      20,
      9,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      4,
      280000,
      6,
      320000,
      8,
      360000,
      10,
      400000,
      13,
      500000
    );
    $harmony_data[1][] = array(
      7,
      "Increases Attack Success, Rate, (PvP)",
      20,
      9,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      5,
      280000,
      7,
      320000,
      9,
      360000,
      11,
      400000,
      14,
      500000
    );
    $harmony_data[1][] = array(
      8,
      "Increases SD Ignore Rate",
      10,
      13,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      15,
      500000
    );

    $harmony_data[2][] = array(
      1,
      "Increases Defense",
      50,
      0,
      3,
      100000,
      4,
      110000,
      5,
      120000,
      6,
      130000,
      7,
      140000,
      8,
      150000,
      10,
      200000,
      12,
      220000,
      14,
      240000,
      16,
      280000,
      18,
      320000,
      20,
      360000,
      22,
      400000,
      25,
      500000
    );
    $harmony_data[2][] = array(
      2,
      "Increases Max AG",
      40,
      3,
      0,
      0,
      0,
      0,
      0,
      0,
      4,
      130000,
      6,
      140000,
      8,
      150000,
      10,
      200000,
      12,
      220000,
      14,
      240000,
      16,
      280000,
      18,
      320000,
      20,
      360000,
      22,
      400000,
      25,
      500000
    );
    $harmony_data[2][] = array(
      3,
      "Increases Max Health",
      40,
      3,
      0,
      0,
      0,
      0,
      0,
      0,
      7,
      130000,
      9,
      140000,
      11,
      150000,
      13,
      200000,
      15,
      220000,
      17,
      240000,
      19,
      280000,
      21,
      320000,
      23,
      360000,
      25,
      400000,
      30,
      500000
    );
    $harmony_data[2][] = array(
      4,
      "Increases Health Regeneration Rate",
      30,
      6,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      200000,
      2,
      220000,
      3,
      240000,
      4,
      280000,
      5,
      320000,
      6,
      360000,
      7,
      400000,
      8,
      500000
    );
    $harmony_data[2][] = array(
      5,
      "Increases Mana Regeneration Rate",
      20,
      9,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      280000,
      2,
      320000,
      3,
      360000,
      4,
      400000,
      5,
      500000
    );
    $harmony_data[2][] = array(
      6,
      "Increases Defense Success Rate (PvP)",
      20,
      9,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      3,
      280000,
      4,
      320000,
      5,
      360000,
      6,
      400000,
      8,
      500000
    );
    $harmony_data[2][] = array(
      7,
      "Increases Damage Reduction",
      20,
      9,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      3,
      280000,
      4,
      320000,
      5,
      360000,
      6,
      400000,
      7,
      500000
    );
    $harmony_data[2][] = array(
      8,
      "Increases SD Ratio Rate",
      10,
      13,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      5,
      500000
    );

    if ($group >= 0 && $group <= 4)
    {
      $harmony = $harmony_data[0];
    }
    if ($group == 5)
    {
      $harmony = $harmony_data[1];
    }
    if ($group >= 6 && $group <= 11)
    {
      $harmony = $harmony_data[2];
    }

    $level = (int)$hlvl;
    $option = (int)$opt;

    if (!isset($harmony[$option - 1]))
    {
      return "undefined harmony option [$option]";
    }
    $harmony = $harmony[$option - 1];

    $option_name = $harmony[1];
    $option_value = $harmony[4 + $level * 2];

    return $option_name . " +$option_value";
  }

  public function getItemX()
  {
    if (!isset(self::$items[$this->group][$this->id]))
    {
      return 0;
    }

    return self::$items[$this->group][$this->id]["Width"];
  }

  public function getItemY()
  {
    if (!isset(self::$items[$this->group][$this->id]))
    {
      return 0;
    }

    return self::$items[$this->group][$this->id]["Height"];
  }

  public function getAncientStatsText()
  {
    return self::$ancient_data->getAdditionalStats($this->group, $this->id, $this->ancient);
  }

  public function getAncientSetId()
  {
    return self::$ancient_data->getSetId($this->group, $this->id, $this->ancient);
  }

  public function getAncientName()
  {
    return self::$ancient_data->getName($this->group, $this->id, $this->ancient);
  }

  public function getAncientOptionName($id)
  {
    return self::$ancient_data->getOptionName($id);
  }

  public function getAncientText()
  {

    if ($this->getAncientSetId() == -1)
    {
      return "<div class='unknown'>Unknown Ancient Set</div>";
    }

    $data = self::$ancient_data->getSetOptions($this->getAncientSetId());

    $text = "";

    for ($i = 1; $i <= 6; $i++)
    {
      if ($data["OptIdx1_{$i}"] != "-1")
      {
        $name = str_replace("%s", $data["OptVal1_{$i}"], $this->getAncientOptionName($data["OptIdx1_{$i}"]));
        $text .= "<div class='item_ancient_OptIdx1_{$i}'>{$name}</div>";
      }
      if ($data["OptIdx2_{$i}"] != "-1")
      {
        $name = str_replace("%s", $data["OptVal2_{$i}"], $this->getAncientOptionName($data["OptIdx2_{$i}"]));
        $text .= "<div class='item_ancient_OptIdx2_{$i}'>{$name}</div>";
      }
    }

    for ($i = 1; $i <= 5; $i++)
    {
      if ($data["FullOptIdx{$i}"] != "-1")
      {
        $name = str_replace("%s", $data["FullOptVal{$i}"], $this->getAncientOptionName($data["FullOptIdx{$i}"]));
        $text .= "<div class='FullOptIdx{$i}'>{$name}</div>";
      }
    }

    return $text;
  }

  public function getSocket()
  {
    $socket = array();
    $k = 0;

    foreach ($this->sockets as $key => $value)
    {
      $opt = $this->getSocketOption($value);
      if (strlen($opt) != 0)
      {
        $socket[$k] = $opt;
        $k++;
      }
    }
    $display = "";
    if (count($socket) > 0)
    {
      $display .= "<div class='item_separator'></div>";
      $display .= "<div class='item_socket_info'>Socket item option info</div>";
      $display .= "<div class='item_separator'></div>";

      foreach ($socket as $key => $value)
      {
        $display .= "<div class='item_socket'>Socket " . ($key + 1) . ": " . $value . "</div>";
      }

      $display .= "<div class='item_separator'></div>";
      $display .= "<div class='item_socket_info'>Bonus socket option</div>";
      $display .= "<div class='item_separator'></div>";
      $display .= "<div class='item_socket_bonus'>Attack power increase +11</div>";
    }

    return $display;
  }

  private function getSocketOption($code)
  {
    if ($code == "FF" || $code == 255)
    {
      return "";
    }
    if ($code == "FE" || $code == 254)
    {
      return "<span style='color: #666666;'>No mounted socket</span>";
    }
    $option = array();
    $option[0] = array(0, 1, 0, "(Fire) Increases Attack & Wizardry +%s", 3, 20, 19, 18, 17, 14, 30);
    $option[1] = array(1, 1, 1, "(Fire) Increases Attack Speed +%s", 1, 7, 8, 9, 10, 11, 20);
    $option[2] = array(2, 1, 2, "(Fire) Increases Maximum Attack & Wizardry +%s", 1, 30, 32, 35, 40, 50, 30);
    $option[3] = array(3, 1, 3, "(Fire) Increases Minimum Attack & Wizardry +%s", 1, 20, 22, 25, 30, 35, 40);
    $option[4] = array(4, 1, 4, "(Fire) Increases Attack & Wizardry +%s", 1, 20, 22, 25, 30, 35, 20);
    $option[5] = array(5, 1, 5, "(Fire) Reduces AG Slightly +%s%", 2, 40, 41, 42, 43, 44, 30);
    $option[10] = array(10, 2, 0, "(Water) Increases Defensibility Accuracy +%s%", 2, 10, 11, 12, 13, 14, 10);
    $option[11] = array(11, 2, 1, "(Water) Increases Defensibility +%s", 1, 30, 33, 36, 39, 42, 30);
    $option[12] = array(12, 2, 2, "(Water) Increases Shield Protection +%s%", 2, 7, 10, 15, 20, 30, 50);
    $option[13] = array(13, 2, 3, "(Water) Reduces Damage +%s%", 2, 4, 5, 6, 7, 8, 20);
    $option[14] = array(14, 2, 4, "(Water) Reflects Damage +%s%", 2, 5, 6, 7, 8, 9, 40);
    $option[16] = array(16, 3, 0, "(Ice) Increases Health From a Mob Kill +%s", 4, 8, 7, 6, 5, 4, 30);
    $option[17] = array(17, 3, 1, "(Ice) Increases Mana From a Mob Kill +%s", 5, 8, 7, 6, 5, 4, 20);
    $option[18] = array(18, 3, 2, "(Ice) Increases Skill Attack +%s", 1, 37, 40, 45, 50, 60, 10);
    $option[19] = array(19, 3, 3, "(Ice) Increases Attack Accuracy +%s", 1, 25, 27, 30, 35, 40, 50);
    $option[20] = array(20, 3, 4, "(Ice) Item Strenghthener +%s", 2, 30, 32, 34, 36, 38, 30);
    $option[21] = array(21, 4, 0, "(Wind) Increases Automatic Health Recovery +%s", 1, 8, 10, 13, 16, 20, 40);
    $option[22] = array(22, 4, 1, "(Wind) Increases Maximum Health +%s%", 2, 4, 5, 6, 7, 8, 30);
    $option[23] = array(23, 4, 2, "(Wind) Increases Maximum Mana +%s%", 2, 4, 5, 6, 7, 8, 40);
    $option[24] = array(24, 4, 3, "(Wind) Increases Automatic Mana Recovery +%s", 1, 7, 14, 21, 28, 35, 50);
    $option[25] = array(25, 4, 4, "(Wind) Increases Maximum AG +%s", 1, 25, 30, 35, 40, 50, 40);
    $option[26] = array(26, 4, 5, "(Wind) Increases AG Value +%s", 1, 3, 5, 7, 10, 15, 50);
    $option[29] = array(29, 5, 0, "(Lightning) Increases Excellent Damage +%s", 1, 15, 20, 25, 30, 40, 20);
    $option[30] = array(30, 5, 1, "(Lightning) Increases Excellent Damage Rate +%s%", 2, 10, 11, 12, 13, 14, 10);
    $option[31] = array(31, 5, 2, "(Lightning) Increases Critical Damage +%s", 1, 30, 32, 35, 40, 50, 30);
    $option[32] = array(32, 5, 3, "(Lightning) Increases Critical Damage Rate +%s%", 2, 8, 9, 10, 11, 12, 10,);
    $option[36] = array(36, 6, 2, "(Lightning) Increases Health +%s", 1, 30, 32, 34, 36, 38, 1);

    for ($i = 1; $i <= 7; $i++)
    {
      if ($code - 50 < 0)
      {
        break;
      }
      $code -= 50;
    }

    if (!isset($option[$code]))
    {
      return "Unknown socket";
    }

    return str_replace("%s", $option[$code][$i + 4], $option[$code][3]);
  }

  public function getImage($path)
  {

    if ($this->is_errtel || $this->is_pentagram)
    {
      $element = $this->bytes[10] % 16;
      if (file_exists($path . $this->group . "/" . $this->group . "-" . $this->id . "-" . $element . ".gif"))
      {
        return $path . $this->group . "/" . $this->group . "-" . $this->id . "-" . $element . ".gif";
      }
    }

    if ($this->group <= 11)
    {
      return $path . $this->group . "/" . $this->group . "-" . $this->id . ".gif";
    }
    if (file_exists($path . $this->group . "/" . $this->group . "-" . $this->id . "-" . $this->level . ".gif"))
    {
      return $path . $this->group . "/" . $this->group . "-" . $this->id . "-" . $this->level . ".gif";
    }

    return $path . $this->group . "/" . $this->group . "-" . $this->id . ".gif";
  }

  public function getDamageTypeText()
  {
    if ($this->data["TwoHand"] == 1)
    {
      return "Two-Handed Damage";
    }
    else
    {
      return "One-Handed Damage";
    }
  }

  public function getAttackSpeed()
  {
    return $this->data["AttackSpeed"];
  }

  public function check_pentagram()
  {
    if ($this->group == 12 && $this->id >= 200 && $this->id <= 214)
    {
      return true;
    }

    return false;
  }

  public function check_errtel()
  {
    if ($this->group == 12 && in_array($this->id, array(221, 231, 241, 251, 261)))
    {
      return true;
    }

    return false;
  }

  public function getInfo($image = true)
  {

    $display = "<div class='item_info'>";
    $display .= "<div class='item_name'>" . $this->getColorizedName() . "</div>";

    if ($this->is_pentagram || $this->is_errtel)
    {
      switch ($this->bytes[10] % 16)
      {
        case 1:
          $display .= "<div class='item_element fire'>(Fire Element)</div>";
          break;
        case 2:
          $display .= "<div class='item_element water'>(Water Element)</div>";
          break;
        case 3:
          $display .= "<div class='item_element earth'>(Earth Element)</div>";
          break;
        case 4:
          $display .= "<div class='item_element wind'>(Wind Element)</div>";
          break;
        case 5:
          $display .= "<div class='item_element darkness'>(Darkness Element)</div>";
          break;
      }
    }


    if ($image)
    {
      $display .= "<div class='item_image'><img src='" . $this->getImage(self::$images_path) . "'></div>";
    }

    $display .= "<div class='item_separator'></div>";

    if (isset($this->data["AttackSpeed"]) && $this->data["AttackSpeed"] > 0)
    {
      $display .= "<div class='attack_speed'>Attack Speed: " . $this->data["AttackSpeed"] . "</div>";
    }

    if ($this->is_pentagram)
    {
      $display .= "<div class='durability'>Trade Limit: " . $this->durability . "</div>";
    }
    elseif (!$this->is_errtel)
    {
      $display .= "<div class='durability'>Durability: " . $this->durability . "</div>";
    }

    if (isset($this->data["ReqLevel"]) && $this->data["ReqLevel"] > 0)
    {
      $display .= "<div class='require_level'>Minimum Level Requirement: " . $this->data["ReqLevel"] . "</div>";
    }

    //    if (isset($this->data["ReqStrength"]) && $this->data["ReqStrength"] > 0)
    //    {
    //      $display .= "<div class='require_strength'>Strength Requirement: " . $this->calcReqStats($this->data["ReqStrength"]) . "</div>";
    //    }
    //
    //    if (isset($this->data["ReqDexterity"]) && $this->data["ReqDexterity"] > 0)
    //    {
    //      $display .= "<div class='require_agility'>Agility Requirement: " . $this->calcReqStats($this->data["ReqDexterity"]) . "</div>";
    //    }
    //
    //    if (isset($this->data["ReqVitality"]) && $this->data["ReqVitality"] > 0)
    //    {
    //      $display .= "<div class='require_vitality'>Vitality Requirement: " . $this->calcReqStats($this->data["ReqVitality"]) . "</div>";
    //    }
    //
    //    if (isset($this->data["ReqEnergy"]) && $this->data["ReqEnergy"] > 0)
    //    {
    //      $display .= "<div class='require_energy'>Energy Requirement: " . $this->calcReqStats($this->data["ReqEnergy"]) . "</div>";
    //    }
    //
    //    if (isset($this->data["ReqCommand"]) && $this->data["ReqCommand"] > 0)
    //    {
    //      $display .= "<div class='require_command'>Command Requirement: " . $this->calcReqStats($this->data["ReqCommand"]) . "</div>";
    //    }

    $classes = array(
      "DarkWizard"     => array(
        "1" => "Dark Wizard",
        "2" => "Soul Master",
        "3" => "Grand Master"
      ),
      "DarkKnight"     => array(
        "1" => "Dark Knight",
        "2" => "Blade Knight",
        "3" => "Blade Master"
      ),
      "FairyElf"       => array(
        "1" => "Fairy Elf",
        "2" => "Muse Elf",
        "3" => "High Elf"
      ),
      "MagicGladiator" => array(
        "1" => "Magic Gladiator",
        "2" => "Duel Master",
        "3" => "Duel Master"
      ),
      "DarkLord"       => array(
        "1" => "Dark Lord",
        "2" => "Lord Emperor",
        "3" => "Lord Emperor"
      ),
      "Summoner"       => array(
        "1" => "Summoner",
        "2" => "Bloody Summoner",
        "3" => "Dimension Master"
      ),
      "RageFighter"    => array(
        "1" => "Rage Fighter",
        "2" => "Fists Master",
        "3" => "Fists Master"
      )
    );


    if (!$this->is_errtel)
    {
      $show_separator = false;

      foreach ($classes as $key => $names)
      {
        if (isset($this->data[$key]) && $this->data[$key] > 0)
        {
          $display .= "<div class='item_separator'></div>";
          $show_separator = true;
          break;
        }
      }

      foreach ($classes as $key => $names)
      {
        if (isset($this->data[$key]) && $this->data[$key] > 0)
        {
          $display .= "<div class='require_class_{$key}'>Can be equipped by {$names[$this->data[$key]]}</div>";
        }
      }

      if ($show_separator)
      {
        $display .= "<div class='item_separator'></div>";
      }

    }

    if ($this->is_pentagram)
    {

    }
    elseif ($this->is_errtel)
    {

    }
    elseif ($this->harmony_type != 0)
    {
      $harm = "weapon";
      if ($this->group == 5)
      {
        $harm = "staff";
      }
      elseif ($this->group >= 6 && $this->group <= 11)
      {
        $harm = "armor";
      }

      if (isset(self::$harmony[$harm][$this->harmony_type][$this->harmony_level]))
      {
        $harm = self::$harmony[$harm][$this->harmony_type][$this->harmony_level]["name"];
      }
      else
      {
        $harm = "Unknown harmony option [{$this->harmony_type}][{$this->harmony_level}]";
      }

      $display .= "<div class='item_separator'></div>";
      $display .= "<div class='item_harmony'>" . $harm . "</div>";
      $display .= "<div class='item_separator'></div>";
    }

    if ($this->ancient > 0)
    {
      $display .= "<div class='item_ancient_stats'>" . $this->getAncientStatsText() . "</div>";
    }

    if ($this->skill && isset($this->data["SkillIndex"]) && $this->data["SkillIndex"] > 0)
    {
      $display .= "<div class='item_skill'>Item has skill</div>";
    }

    if ($this->luck != 0)
    {
      $display .= "<div class='item_luck'>Luck (success rate of Jewel of Soul +25%)</div>";
      $display .= "<div class='item_luck'>Luck (critical damage rate +5%)</div>";
    }

    if ($this->option != 0)
    {
      $display .= "<div class='item_option'>" . $this->getOptionText() . "</div>";
    }

    if ($this->excellent != 0)
    {
      $display .= "<div class='item_excellent'>" . $this->getExcellentOptionsText() . "</div>";
    }

    if ($this->pvp)
    {
      $display .= "<div class='item_separator'></div>";
      $display .= "<div class='item_refinery'>" . $this->getPvpText() . "</div>";
    }

    if ($this->is_pentagram)
    {
      $display .= "<div class='item_separator'></div>";

      $slots = array("Anger", "Blessing", "Integrity", "Divinity", "Gale");
      foreach ($this->sockets as $key => $socket)
      {
        if ($socket == 255)
        {
          continue;
        }
        else
        {
          $number = $key + 1;
          $display .= "<div class='item_pentagram_slot'>Slot of {$slots[$key]} ({$number})</div>";
          if ($socket == 254)
          {
            $display .= "<div class='item_pentagram_option'>None</div>";
          }
          else
          {
            $display .= "<div class='item_pentagram_option'>Errtel of {$slots[$key]}</div>";
          }
        }
      }

    }
    elseif ($this->is_errtel)
    {
      $rank = $this->bytes[10] % 16;
      $display .= "<div class='item_separator'></div>";
      $display .= "<div class='item_errtel_rank'>{$rank} Rank Errtel</div>";

      foreach ($this->sockets as $key => $socket)
      {
        if ($socket == 255)
        {
          continue;
        }
        else
        {
          $options = Item::$elemental[12][$this->id][$key + 1];
          $option = $options[$socket % 16 - 1];
          $level = intval($socket / 16);
          $number = $key + 1;
          $name = str_replace(array("%d%", "%d"), $option["OptionValue" . $level], $option["Name"]);
          $display .= "<div class='item_errtel_slot'>{$number} Rank Option +{$level}</div>";
          $display .= "<div class='item_errtel_option'>{$name}</div>";
        }
      }
    }
    else
    {
      $header = false;
      foreach ($this->sockets as $key => $socket)
      {
        if ($socket <= 254 && !$header)
        {
          $header = true;
          $display .= "<div class='item_separator'></div>";
          $display .= "<div class='item_socket_info'>Socket item option info</div>";
          $display .= "<div class='item_separator'></div>";
        }
        if ($socket < 254)
        {
          $display .= "<div class='item_socket'>Socket " . ($key + 1) . ": " . self::$socket[$socket]["name"] . "</div>";
        }
        elseif ($socket == 254)
        {
          $display .= "<div class='item_socket empty'>Socket " . ($key + 1) . ": (Empty Socket)</div>";
        }
      }
    }

    if ($this->ancient != 0)
    {
      $display .= "<div class='item_separator'></div>";
      $display .= "<div class='item_ancient_info'>Set Item option info</div>";
      $display .= "<div class='item_separator'></div>";
      $display .= "<div class='item_ancient'>" . $this->getAncientText() . "</div>";
    }

    $display .= "</div>";

    return $display;
  }

}
