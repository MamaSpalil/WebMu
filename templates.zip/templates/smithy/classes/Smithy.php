<?php

/**
 * Created by PhpStorm.
 * User: Profesor08
 * Date: 17.02.2016
 * Time: 2:39
 */
class Smithy
{

  public $class_short = array("dw", "dk", "elf", "mg", "dl", "sum", "rf", "gl");
  public $class_name = array(
    "dw"  => "Dark Wizard",
    "dk"  => "Dark Knight",
    "elf" => "Fairy Elf",
    "mg"  => "Magic Gladiator",
    "dl"  => "Dark Lord",
    "sum" => "Summoner",
    "rf"  => "Rage Fighter",
	"gl"  => "Grow Lancer"
  );
  public $item_type = array("excellent", "ancient", "socket", "elemental", "pets");

  public function __construct(SQL $db, $user, $divider)
  {
    $this->divider = $divider;
    $this->db = $db;
    $this->user = $user;
    $this->parser = new CI_Parser("templates/smithy/view/");
    $this->items = json_decode(file_get_contents("templates/smithy/config/item.json"), true);
    $this->option = json_decode(file_get_contents("templates/smithy/config/options.json"), true);
    $this->excellent = json_decode(file_get_contents("templates/smithy/config/excellent.json"), true);
    $this->volute = $this->get_volute();
  }

  public function index()
  {
    $data["classes"] = array();
    foreach ($this->class_short as $class)
    {
      $data["classes"][] = array(
        "class" => $class,
        "name"  => isset($this->class_name[$class]) ? $this->class_name[$class] : "unknown"
      );
    }
    echo $this->parser->parse("main.html", $data, true);
  }

  private function get_volute()
  {
    $query = $this->db->Query("SELECT {$this->option["volute"]["column"]} FROM {$this->option["volute"]["table"]} WHERE {$this->option["volute"]["user"]} = '{$this->user}'");
    $result = $this->db->FetchAssoc($query);

    return $result[$this->option["volute"]["column"]];
  }

  private function set_volute($value)
  {
    $this->db->Query("UPDATE {$this->option["volute"]["table"]} SET {$this->option["volute"]["column"]} = {$value} WHERE {$this->option["volute"]["user"]} = '{$this->user}'");
    $this->volute = $this->get_volute();
  }

  public function select_item_menu($class, $item_type, $item_group, $id)
  {
    $data["class_img"] = $class;
    $data["item_types"] = array();
    $data["classes"] = array();
    $data["items_groups"] = array();
    $data["items_list"] = array();
    $data["selected_item"] = array();
    $data["volute"] = $this->volute;
    $data["divider"] = $this->divider;

    foreach ($this->item_type as $type)
    {
      $data["item_types"][] = array(
        "type"   => $type,
        "class"  => $class,
        "active" => $item_type == $type ? "active" : ""
      );
    }

    foreach ($this->class_short as $class_short)
    {
      $data["classes"][] = array(
        "class"     => $class_short,
        "item_type" => $item_type,
        "name"      => isset($this->class_name[$class_short]) ? $this->class_name[$class_short] : "unknown",
        "active"    => $class_short == $class ? "active" : ""
      );
    }

    if (isset($this->items[$class][$item_type]))
    {
      foreach ($this->items[$class][$item_type] as $key => $value)
      {
        $data["items_groups"][] = array(
          "name"      => $key,
          "class"     => $class,
          "item_type" => $item_type,
          "active"    => $key == $item_group ? "active" : ""
        );
      }
    }

    if (isset($this->items[$class][$item_type][$item_group]))
    {
      foreach ($this->items[$class][$item_type][$item_group] as $key => $value)
      {
        $item = new Item((new ItemOptions($value["group"], $value["id"], 0, 0, 0, 0, 0, 255, isset($value["ancient"]) ? $value["ancient"] : 0))->getBytes());
        $data["items_list"][] = array(
          "name"       => $item->getName(),
          "class"      => $class,
          "item_type"  => $item_type,
          "item_group" => $item_group,
          "id"         => $key,
          "active"     => $key == $id ? "active" : ""
        );
      }
    }

    if (isset($this->items[$class][$item_type][$item_group][$id]))
    {

      $info = $this->items[$class][$item_type][$item_group][$id];

      if ($item_type == "elemental" && $item_group == "pentagram")
      {
        $item = new Item((new ItemOptions($info["group"], $info["id"]))->getBytes());
        $selected_item_options = $this->pentagram_options($info, $item);
      }
      elseif ($item_type == "elemental" && $item_group == "errtel")
      {
        $item = new Item((new ItemOptions($info["group"], $info["id"]))->getBytes());
        $selected_item_options = $this->errtel_options($info, $item);
      }
      elseif ($item_type == "ancient")
      {
        $item = new Item((new ItemOptions($info["group"], $info["id"], 0, 0, 0, 0, 0, 255, isset($info["ancient"]) ? $info["ancient"] : 0))->getBytes());
        $selected_item_options = $this->ancient_options($info, $item);
      }
      elseif ($item_type == "socket")
      {
        $item = new Item((new ItemOptions($info["group"], $info["id"], 0, 0, 0, 0, 0, 255))->getBytes());
        $selected_item_options = $this->socket_options($info, $item);
      }
      elseif ($item_type == "excellent")
      {
        $item = new Item((new ItemOptions($info["group"], $info["id"], 0, 0, 0, 0, 0, 255))->getBytes());
        $selected_item_options = $this->excellent_options($info, $item);
      }
      elseif ($item_type == "pets")
      {
        $item = new Item((new ItemOptions($info["group"], $info["id"], 0, 0, 0, 0, 0, 255))->getBytes());
        $selected_item_options = $this->pets_options();
      }
      else
      {
        $item = new Item((new ItemOptions($info["group"], $info["id"]))->getBytes());
      }

      $data["selected_item"][] = array(
        "image"                 => $item->getImage("images/items/demo/"),
        "item_name"             => $item->getName(),
        "item_price"            => $info["price"],
        "selected_item_options" => isset($selected_item_options) ? $selected_item_options : ""
      );

    }

    echo $this->parser->parse("main.html", $data, true);
  }

  private function pets_options()
  {
    $data["destroy"] = $this->option["price"]["fenrir"][0];
    $data["protect"] = $this->option["price"]["fenrir"][1];
    $data["illusion"] = $this->option["price"]["fenrir"][2];

    return $this->parser->parse("pets.html", $data, true);
  }

  private function excellent_options($info, Item $item)
  {
    $data["options"] = array();
    $data["levels"] = array();
    $data["luck"] = array();
    $data["skill"] = array();
    $data["excellent"] = array();
    $data["harmony_block"] = array();

    $options_multiplier = 4;

    $options_text = "Additional Option";

    if ($item->group <= 4)
    {
      $options_text = "Additional Damage";
    }
    if ($item->group == 5)
    {
      $options_text = "Additional Wizardly Dmg";
    }
    elseif ($item->group == 6)
    {
      $options_text = "Additional Defense rate";
      $options_multiplier = 5;
    }

    for ($i = 0; $i <= $info["option"]; $i++)
    {
      $data["options"][] = array(
        "option"       => $i,
        "price"        => $this->option["price"]["option"][$i],
        "option_title" => "{$options_text} +" . ($i * $options_multiplier)
      );
    }

    for ($i = 0; $i <= $info["level"]; $i++)
    {
      $data["levels"][] = array(
        "level"       => $i,
        "price"       => $this->option["price"]["level"][$i],
        "level_title" => "{$item->getName()} +{$i}"
      );
    }

    if ($info["luck"])
    {
      $data["luck"][] = array(
        "price" => $this->option["price"]["luck"]
      );
    }

    if ($info["skill"])
    {
      $data["skill"][] = array(
        "price" => $this->option["price"]["skill"]
      );
    }

    if ($info["harmony"])
    {
      if ($item->group <= 4)
      {
        $harmony = Item::$harmony["weapon"];
      }
      elseif ($item->group == 5)
      {
        $harmony = Item::$harmony["staff"];
      }
      elseif ($item->group <= 11)
      {
        $harmony = Item::$harmony["armor"];
      }
      else
      {
        $harmony = Item::$harmony["weapon"];
      }

      foreach ($harmony as $harmony_type => $harmony_type_group)
      {
        foreach ($harmony_type_group as $harmony_option => $harmony_option_data)
        {
          $harmony_select[] = array(
            "id"    => "{$harmony_type}|{$harmony_option}",
            "price" => $harmony_option_data["price"],
            "name"  => $harmony_option_data["name"]
          );
        }
      }

      if (isset($harmony_select))
      {
        $data["harmony_block"][] = array(
          "harmony" => $harmony_select
        );
      }
    }


    if ($info["excellent"])
    {
      for ($i = 0; $i <= $info["excellent"] - 1; $i++)
      {
        $exc = pow(2, $i);

        if (!$item->getExcellentOptionText($exc))
        {
          break;
        }

        if ($item->group <= 5)
        {
          $price = $this->excellent["weapon"];
        }
        elseif ($item->group <= 11)
        {
          $price = $this->excellent["armor"];
        }
        else
        {
          $price = $this->excellent["weapon"];
        }

        $data["excellent"][] = array(
          "id"    => $exc,
          "price" => $price[$exc],
          "name"  => $item->getExcellentOptionText($exc)
        );
      }
    }

    return $this->parser->parse("excellent.html", $data, true);
  }

  private function socket_options($info, Item $item)
  {
    $data["options"] = array();
    $data["levels"] = array();
    $data["luck"] = array();
    $data["skill"] = array();
    $data["socket"] = array();
    $data["excellent"] = array();

    $options_multiplier = 4;

    $options_text = "Additional Option";

    if ($item->group <= 4)
    {
      $options_text = "Additional Damage";
    }
    if ($item->group == 5)
    {
      $options_text = "Additional Wizardly Dmg";
    }
    elseif ($item->group == 6)
    {
      $options_text = "Additional Defense rate";
      $options_multiplier = 5;
    }

    for ($i = 0; $i <= $info["option"]; $i++)
    {
      $data["options"][] = array(
        "option"       => $i,
        "price"        => $this->option["price"]["option"][$i],
        "option_title" => "{$options_text} +" . ($i * $options_multiplier)
      );
    }

    for ($i = 0; $i <= $info["level"]; $i++)
    {
      $data["levels"][] = array(
        "level"       => $i,
        "price"       => $this->option["price"]["level"][$i],
        "level_title" => "{$item->getName()} +{$i}"
      );
    }

    if ($info["luck"])
    {
      $data["luck"][] = array(
        "price" => $this->option["price"]["luck"]
      );
    }

    if ($info["skill"])
    {
      $data["skill"][] = array(
        "price" => $this->option["price"]["skill"]
      );
    }

    if ($info["socket"])
    {
      for ($i = 0; $i < $info["socket"]; $i++)
      {
        $data["socket"][$i]["block"] = $i + 1;
        foreach (Item::$socket as $key => $socket)
        {
          $data["socket"][$i]["option"][] = array(
            "id"    => $key,
            "price" => $socket["price"],
            "name"  => $socket["name"]
          );
        }
      }
    }

    for ($i = 0; $i <= 5; $i++)
    {
      $exc = pow(2, $i);

      if (!$item->getExcellentOptionText($exc))
      {
        break;
      }

      if ($item->group <= 5)
      {
        $price = $this->excellent["weapon"];
      }
      elseif ($item->group <= 11)
      {
        $price = $this->excellent["armor"];
      }
      else
      {
        $price = $this->excellent["weapon"];
      }

      $data["excellent"][] = array(
        "id"    => $exc,
        "price" => $price[$exc],
        "name"  => $item->getExcellentOptionText($exc)
      );
    }

    return $this->parser->parse("socket.html", $data, true);
  }

  private function ancient_options($info, Item $item)
  {
    $data["options"] = array();
    $data["levels"] = array();
    $data["luck"] = array();
    $data["skill"] = array();
    $data["ancient_text"] = array();
    $data["harmony_block"] = array();

    $options_multiplier = 4;

    $options_text = "Additional Option";

    if ($item->group <= 4)
    {
      $options_text = "Additional Damage";
    }
    if ($item->group == 5)
    {
      $options_text = "Additional Wizardly Dmg";
    }
    elseif ($item->group == 6)
    {
      $options_text = "Additional Defense rate";
      $options_multiplier = 5;
    }

    for ($i = 0; $i <= $info["option"]; $i++)
    {
      $data["options"][] = array(
        "option"       => $i,
        "price"        => $this->option["price"]["option"][$i],
        "option_title" => "{$options_text} +" . ($i * $options_multiplier)
      );
    }

    for ($i = 0; $i <= $info["level"]; $i++)
    {
      $data["levels"][] = array(
        "level"       => $i,
        "price"       => $this->option["price"]["level"][$i],
        "level_title" => "{$item->getName()} +{$i}"
      );
    }

    if ($info["luck"])
    {
      $data["luck"][] = array(
        "price" => $this->option["price"]["luck"]
      );
    }

    if ($info["skill"])
    {
      $data["skill"][] = array(
        "price" => $this->option["price"]["skill"]
      );
    }

    if ($item->group <= 4)
    {
      $harmony = Item::$harmony["weapon"];
    }
    elseif ($item->group == 5)
    {
      $harmony = Item::$harmony["staff"];
    }
    elseif ($item->group <= 11)
    {
      $harmony = Item::$harmony["armor"];
    }
    else
    {
      $harmony = Item::$harmony["weapon"];
    }

    if ($info["harmony"])
    {
      foreach ($harmony as $harmony_type => $harmony_type_group)
      {
        foreach ($harmony_type_group as $harmony_option => $harmony_option_data)
        {
          $harmony_select[] = array(
            "id"    => "{$harmony_type}|{$harmony_option}",
            "price" => $harmony_option_data["price"],
            "name"  => $harmony_option_data["name"]
          );
        }
      }
    }

    if (isset($harmony_select))
    {
      $data["harmony_block"][] = array(
        "harmony" => $harmony_select
      );
    }

    if ($info["ancient"])
    {
      $data["ancient_text"] = $item->getAncientText();
    }

    return $this->parser->parse("ancient.html", $data, true);
  }

  private function pentagram_options($info, Item $item)
  {

    $data["levels"] = array();
    $data["element"] = array();
    $data["slots"] = array();

    for ($i = 0; $i <= $info["level"]; $i++)
    {
      $data["levels"][] = array(
        "level"       => $i,
        "price"       => $this->option["price"]["level"][$i],
        "level_title" => "{$item->getName()} +{$i}"
      );
    }

    $element = array("Fire", "Water", "Earth", "Wind", "Darkness");
    foreach ($element as $key => $name)
    {
      $data["element"][] = array(
        "id"    => $key + 1,
        "price" => $this->option["price"]["pentagram_element"][$key],
        "name"  => $name
      );
    }

    $slots = array("Slot of Anger", "Slot of Blessing", "Slot of Integrity", "Slot of Divinity", "Slot of Gale");
    for ($i = 0; $i < $info["slots"]; $i++)
    {
      $data["slots"][] = array(
        "id"    => $i,
        "price" => $this->option["price"]["pentagram_slots"][$i + 1],
        "name"  => $slots[$i]
      );
    }

    return $this->parser->parse("pentagram.html", $data, true);
  }

  private function errtel_options($info, Item $item)
  {

    $data["element"] = array();
    $data["slots"] = array();

    $element = array("Fire", "Water", "Earth", "Wind", "Darkness");
    foreach ($element as $key => $name)
    {
      $data["element"][] = array(
        "id"    => $key + 1,
        "price" => $this->option["price"]["pentagram_element"][$key],
        "name"  => $name
      );
    }

    $level = array();
    for ($i = 0; $i <= $info["level"]; $i++)
    {
      $level[] = array(
        "id"    => $i,
        "price" => $this->option["price"]["errtel_level"][$i],
        "name"  => "+" . $i
      );
    }


    for ($i = 1; $i <= $info["slots"]; $i++)
    {

      $option = array();
      $generated_js = "";
      $options = Item::$elemental[$item->group][$item->id][$i];

      foreach ($options as $key => $errtel)
      {
        $option[] = array(
          "id"    => $key,
          "price" => $errtel["price"],
          "name"  => str_replace(array("%d%", "%d"), $errtel["OptionValue0"], $errtel["Name"])
        );
      }

      for ($j = 0; $j <= $info["level"]; $j++)
      {
        $generated_js .= "options[{$j}] = [];\n";
        foreach ($options as $k => $errtel)
        {
          $msg = str_replace(array("%d%", "%d"), $errtel["OptionValue" . $j], $errtel["Name"]);
          $generated_js .= "options[{$j}][{$k}] = \"{$msg}\";\n";
        }
      }

      $data["slots"][] = array(
        "rank"         => $i,
        "level"        => $level,
        "option"       => $option,
        "generated_js" => $generated_js
      );
    }

    return $this->parser->parse("errtel.html", $data, true);
  }

  public function buy_errtel($class, $item_type, $item_group, $id)
  {
    $info = $this->items[$class][$item_type][$item_group][$id];

    $price = $info["price"];

    if (!isset($_POST["element"]))
    {
      throw new Exception("no element");
    }

    if (!in_array($_POST["element"], array(1, 2, 3, 4, 5)))
    {
      throw new Exception("wrong element");
    }

    $item = new ItemOptions($info["group"], $info["id"]);
    $item_hex = $item->getHex() . "00000000" . "FFFFFFFFFFFFFFFFFFFFFFFF";

    $item_bytes = unpack("C*", hex2bin($item_hex));

    $slots = intval($_POST["element"]);

    $level = 0;

    for ($i = 1; $i <= $info["slots"]; $i++)
    {
      if (!isset($_POST["slot_" . $i]) || !isset($_POST["level_" . $i]))
      {
        throw new Exception("no errtel option or level");
      }

      if (!ctype_digit($_POST["slot_" . $i]))
      {
        continue;
      }

      if (!ctype_digit($_POST["level_" . $i]) || $_POST["level_" . $i] < 0 || $_POST["level_" . $i] > $info["level"])
      {
        throw new Exception("wrong errtel level: " . $_POST["level_" . $i]);
      }

      if (!isset(Item::$elemental[$info["group"]][$info["id"]][$i]))
      {
        throw new Exception("wrong errtel rank: " . $i);
      }

      if (!isset(Item::$elemental[$info["group"]][$info["id"]][$i][$_POST["slot_" . $i]]))
      {
        throw new Exception("wrong errtel option: " . $i);
      }

      if ($_POST["level_" . $i] > $level)
      {
        $level = $_POST["level_" . $i];
      }

      $errtel = Item::$elemental[$info["group"]][$info["id"]][$i][$_POST["slot_" . $i]];

      $item_bytes[11 + $i] = $errtel["OptionNum"] + intval($_POST["level_" . $i]) * 16;

      $slots += 16;

      $price += $this->option["price"]["errtel_level"][$level];

      $price += Item::$elemental[$info["group"]][$info["id"]][$i][$_POST["slot_" . $i]]["price"];

    }

    $price += $this->option["price"]["pentagram_element"][$_POST["element"]];

    $item_bytes[11] = $slots;
    //    $item_bytes[2] = $level * 8;

    $price = intval($price / $this->divider);

    if ($price > $this->volute)
    {
      throw new Exception("not enough WCoinC");
    }

    $this->set_volute($this->volute - $price);

    $this->add_to_warehouse($item_bytes, $price);
  }

  public function buy_pentagram($class, $item_type, $item_group, $id)
  {

    if (!isset($this->items[$class][$item_type][$item_group][$id]))
    {
      throw new Exception("wrong item id: " . $id);
    }

    $info = $this->items[$class][$item_type][$item_group][$id];

    $price = $info["price"];

    if (!isset($_POST["element"]))
    {
      throw new Exception("no element");
    }

    if (!in_array($_POST["element"], array(1, 2, 3, 4, 5)))
    {
      throw new Exception("wrong element");
    }

    if (!isset($_POST["level"]))
    {
      throw new Exception("no level");
    }

    if (!ctype_digit($_POST["level"]) || ($_POST["level"] > $info["level"]))
    {
      throw new Exception("wrong level: " . $info["level"]);
    }

    $item = new ItemOptions($info["group"], $info["id"], intval($_POST["level"]), 0, 0, 0, 0, 5);
    $item_hex = $item->getHex() . "00000000" . "FFFFFFFFFFFFFFFFFFFFFFFF";
    $item_hex = substr_replace($item_hex, "1" . $_POST["element"], 20, 2);

    $item_bytes = unpack("C*", hex2bin($item_hex));

    for ($i = 0; $i < $info["slots"]; $i++)
    {
      if (isset($_POST["slot_" . $i]))
      {
        $item_bytes[12 + $i] = 254;
        $price += $this->option["price"]["pentagram_slots"][$i + 1];
      }
    }

    $price += $this->option["price"]["level"][$_POST["level"]];

    $price += $this->option["price"]["pentagram_element"][$_POST["element"]];

    $price = intval($price / $this->divider);

    if ($price > $this->volute)
    {
      throw new Exception("not enough WCoinC");
    }

    $this->set_volute($this->volute - $price);

    $this->add_to_warehouse($item_bytes, $price);
  }

  public function buy_pets($class, $item_type, $item_group, $id)
  {

    if (!isset($_POST["excellent"]))
    {
      return;
    }

    if (!isset($this->items[$class][$item_type][$item_group][$id]))
    {
      throw new Exception("wrong item id: " . $id);
    }

    if (!isset($this->option["price"]["fenrir"][$_POST["excellent"]]))
    {
      throw new Exception("wrong item option: " . $_POST["excellent"]);
    }

    $info = $this->items[$class][$item_type][$item_group][$id];

    $price = $info["price"] + $this->option["price"]["fenrir"][$_POST["excellent"]];

    $option = 0;
    switch ($_POST["excellent"])
    {
      case 0:
        $option = 1;
        break;
      case 1:
        $option = 2;
        break;
      case 2:
        $option = 4;
        break;
    }

    $item = new ItemOptions($info["group"], $info["id"], 0, 0, 0, 0, $option, 255);

    $price = intval($price / $this->divider);

    if ($price > $this->volute)
    {
      throw new Exception("not enough WCoinC");
    }

    $this->set_volute($this->volute - $price);

    $this->add_to_warehouse($item->getHex() . "00000000" . "FFFFFFFFFFFFFFFFFFFFFFFF", $price);
  }

  private function buy_excellent($class, $item_type, $item_group, $id)
  {

    if (!isset($this->items[$class][$item_type][$item_group][$id]))
    {
      throw new Exception("wrong item id: " . $id);
    }

    $info = $this->items[$class][$item_type][$item_group][$id];

    $price = $info["price"];

    if (!ctype_digit($_POST["level"]) || ($_POST["level"] > $info["level"]))
    {
      throw new Exception("wrong level: " . $info["level"]);
    }

    $price += $this->option["price"]["level"][$_POST["level"]];

    if (!ctype_digit($_POST["option"]) || ($_POST["option"] > $info["option"]))
    {
      throw new Exception("wrong option: " . $info["option"]);
    }

    $price += $this->option["price"]["option"][$_POST["option"]];

    if (isset($_POST["luck"]) && $info["luck"])
    {
      $luck = 1;
      $price += $this->option["price"]["luck"];
    }
    else
    {
      $luck = 0;
    }

    if (isset($_POST["skill"]) && $info["skill"])
    {
      $skill = 1;
      $price += $this->option["price"]["skill"];
    }
    else
    {
      $skill = 0;
    }

    $excellent = 0;

    if ($info["excellent"])
    {
      for ($i = 0; $i <= $info["excellent"] - 1; $i++)
      {
        $exc = pow(2, $i);

        if (isset($_POST["excellent_" . $exc]))
        {
          $excellent += $exc;
          if ($info["group"] <= 5 || $info["group"] >= 12)
          {
            $price += $this->excellent["weapon"][$exc];
          }
          else
          {
            $price += $this->excellent["armor"][$exc];
          }
        }
      }
    }

    $harmony_group = 0;
    $harmony_level = 0;

    if (isset($_POST["harmony"]) && $_POST["harmony"] != -1)
    {
      if ($info["group"] <= 4)
      {
        $harmony = Item::$harmony["weapon"];
      }
      elseif ($info["group"] == 5)
      {
        $harmony = Item::$harmony["staff"];
      }
      elseif ($info["group"] <= 11)
      {
        $harmony = Item::$harmony["armor"];
      }
      else
      {
        $harmony = Item::$harmony["weapon"];
      }

      $option = explode("|", $_POST["harmony"]);

      if (!isset($harmony[$option[0]]) || !isset($harmony[$option[0]][$option[1]]))
      {
        throw new Exception("wrong harmony option: {$option[0]} - {$option[1]}");
      }

      $harmony_group = $option[0];
      $harmony_level = $option[1];

      $price += $harmony[$option[0]][$option[1]]["price"];

    }

    $item = new ItemOptions($info["group"], $info["id"], intval($_POST["level"]), intval($_POST["option"]), $luck, $skill, $excellent, 255, 0, 0, $harmony_group, $harmony_level);

    $price = intval($price / $this->divider);

    if ($price > $this->volute)
    {
      throw new Exception("not enough WCoinC");
    }

    $this->set_volute($this->volute - $price);

    $this->add_to_warehouse($item->getHex() . "00000000" . "FFFFFFFFFFFFFFFFFFFFFFFF", $price);
  }

  private function buy_ancient($class, $item_type, $item_group, $id)
  {

    if (!isset($this->items[$class][$item_type][$item_group][$id]))
    {
      throw new Exception("wrong item id: " . $id);
    }

    $info = $this->items[$class][$item_type][$item_group][$id];

    $price = $info["price"];

    if (!ctype_digit($_POST["level"]) || ($_POST["level"] > $info["level"]))
    {
      throw new Exception("wrong level: " . $info["level"]);
    }

    $price += $this->option["price"]["level"][$_POST["level"]];

    if (!ctype_digit($_POST["option"]) || ($_POST["option"] > $info["option"]))
    {
      throw new Exception("wrong option: " . $info["option"]);
    }

    $price += $this->option["price"]["option"][$_POST["option"]];

    if (isset($_POST["luck"]) && $info["luck"])
    {
      $luck = 1;
      $price += $this->option["price"]["luck"];
    }
    else
    {
      $luck = 0;
    }

    if (isset($_POST["skill"]) && $info["skill"])
    {
      $skill = 1;
      $price += $this->option["price"]["skill"];
    }
    else
    {
      $skill = 0;
    }

    $harmony_group = 0;
    $harmony_level = 0;

    if (isset($_POST["harmony"]) && $_POST["harmony"] != -1 && $info["harmony"])
    {
      if ($info["group"] <= 4)
      {
        $harmony = Item::$harmony["weapon"];
      }
      elseif ($info["group"] == 5)
      {
        $harmony = Item::$harmony["staff"];
      }
      elseif ($info["group"] <= 11)
      {
        $harmony = Item::$harmony["armor"];
      }
      else
      {
        $harmony = Item::$harmony["weapon"];
      }

      $option = explode("|", $_POST["harmony"]);

      if (!isset($harmony[$option[0]]) || !isset($harmony[$option[0]][$option[1]]))
      {
        throw new Exception("wrong harmony option: {$option[0]} - {$option[1]}");
      }

      $harmony_group = $option[0];
      $harmony_level = $option[1];

      $price += $harmony[$option[0]][$option[1]]["price"];

    }

    $item = new ItemOptions($info["group"], $info["id"], intval($_POST["level"]), intval($_POST["option"]), $luck, $skill, 0, 255, $info["ancient"], 0, $harmony_group, $harmony_level);

    $price = intval($price / $this->divider);

    if ($price > $this->volute)
    {
      throw new Exception("not enough WCoinC");
    }

    $this->set_volute($this->volute - $price);

    $this->add_to_warehouse($item->getHex() . "00000000" . "FFFFFFFFFFFFFFFFFFFFFFFF", $price);
  }

  private function buy_socket($class, $item_type, $item_group, $id)
  {

    if (!isset($this->items[$class][$item_type][$item_group][$id]))
    {
      throw new Exception("wrong item id: " . $id);
    }

    $info = $this->items[$class][$item_type][$item_group][$id];

    $price = $info["price"];

    if (!ctype_digit($_POST["level"]) || ($_POST["level"] > $info["level"]))
    {
      throw new Exception("wrong level: " . $info["level"]);
    }

    $price += $this->option["price"]["level"][$_POST["level"]];

    if (!ctype_digit($_POST["option"]) || ($_POST["option"] > $info["option"]))
    {
      throw new Exception("wrong option: " . $info["option"]);
    }

    $price += $this->option["price"]["option"][$_POST["option"]];

    if (isset($_POST["luck"]) && $info["luck"])
    {
      $luck = 1;
      $price += $this->option["price"]["luck"];
    }
    else
    {
      $luck = 0;
    }

    if (isset($_POST["skill"]) && $info["skill"])
    {
      $skill = 1;
      $price += $this->option["price"]["skill"];
    }
    else
    {
      $skill = 0;
    }

    $socket = array(255, 255, 255, 255, 255);

    if ($info["socket"])
    {
      for ($i = 1; $i <= $info["socket"]; $i++)
      {
        if (isset($_POST["socket_" . $i]) && $_POST["socket_" . $i] != -1)
        {
          if (!isset(Item::$socket[$_POST["socket_" . $i]]))
          {
            throw new Exception("unknown socket: " . $_POST["socket_" . $i]);
          }

          $price += Item::$socket[$_POST["socket_" . $i]]["price"];

          $socket[$i - 1] = $_POST["socket_" . $i];

        }
      }
    }

    $excellent = 0;

    for ($i = 0; $i <= 6 - 1; $i++)
    {
      $exc = pow(2, $i);

      if (isset($_POST["excellent_" . $exc]))
      {
        $excellent += $exc;
        if ($info["group"] <= 5 || $info["group"] >= 12)
        {
          $price += $this->excellent["weapon"][$exc];
        }
        else
        {
          $price += $this->excellent["armor"][$exc];
        }
      }
    }

    $item = new ItemOptions($info["group"], $info["id"], intval($_POST["level"]), intval($_POST["option"]), $luck, $skill, $excellent, 255, 0, 0, 0, 0, $socket[0], $socket[1], $socket[2], $socket[3], $socket[4]);

    $price = intval($price / $this->divider);

    if ($price > $this->volute)
    {
      throw new Exception("not enough WCoinC");
    }

    $this->set_volute($this->volute - $price);

    $this->add_to_warehouse($item->getHex() . "00000000" . "FFFFFFFFFFFFFFFFFFFFFFFF", $price);
  }

  public function action($class, $item_type, $item_group, $id)
  {
    if (!isset($_POST["buy_item"]))
    {
      return;
    }

    try
    {

      if (!isset($this->items[$class]) || !isset($this->items[$class][$item_type]) || !isset($this->items[$class][$item_type][$item_group]) || !isset($this->items[$class][$item_type][$item_group][$id]))
      {
        throw new Exception("no item");
      }

      if ($item_type == "elemental" && $item_group == "errtel")
      {
        $this->buy_errtel($class, $item_type, $item_group, $id);
      }
      elseif ($item_type == "elemental" && $item_group == "pentagram")
      {
        $this->buy_pentagram($class, $item_type, $item_group, $id);
      }
      elseif ($item_type == "ancient")
      {
        $this->buy_ancient($class, $item_type, $item_group, $id);
      }
      elseif ($item_type == "socket")
      {
        $this->buy_socket($class, $item_type, $item_group, $id);
      }
      elseif ($item_type == "excellent")
      {
        $this->buy_excellent($class, $item_type, $item_group, $id);
      }
      elseif ($item_type == "pets")
      {
        $this->buy_pets($class, $item_type, $item_group, $id);
      }

    }
    catch (Exception $ex)
    {
      global $Engine;
      echo $Engine->Message("error", $ex->getMessage());
    }

  }

  private function get_serial()
  {
    $result = $this->db->Query("exec WZ_GetItemSerial");
    $data = mssql_fetch_row($result);

    //    return sprintf("%08X", $data[0], 00000000);
    return $data[0];
  }

  public function add_to_warehouse($item, $price)
  {
    if (!is_array($item))
    {
      $item = unpack("C*", hex2bin($item));
    }

    $serial_int = $this->get_serial();

    $serial = unpack("C*", hex2bin(sprintf("%08X", $serial_int, 00000000)));

    $offset = key($item);

    foreach ($serial as $key => $byte)
    {
      $item[15 + $offset + $key] = $byte;
    }

        $chars = array_map("chr", $item);
        $bin = join("", $chars);
        $item_hex = strtoupper(bin2hex($bin));

        $this->db->Query("INSERT INTO pr_smithy (memb___id, item_serial, price) VALUES ('{$this->user}', {$serial_int}, {$price})");
        $this->db->Query("INSERT INTO pr_webware_items (memb___id, item) VALUES ('{$this->user}', '{$item_hex}')");


//    $result = $this->db->FetchAssoc($this->db->Query("SELECT CAST(Items AS varchar(MAX)) as items FROM warehouse WHERE AccountID='{$this->user}'"));
//
//    $ware_items = unpack("C*", $result["items"]);
//
//    $ware = new WarehouseDecoder($ware_items, 32);
//
//    $position = $ware->find_free_space($item);
//
//    if ($position == -1)
//    {
//      throw new Exception("no free space");
//    }
//
//    foreach ($item as $i => $byte)
//    {
//      $ware_items[$position + $i] = $byte;
//    }
//
//    $chars = array_map("chr", $ware_items);
//    $bin = join("", $chars);
//    $ware_hex = strtoupper(bin2hex($bin));
//
//    $this->db->Query("UPDATE warehouse SET Items=0x{$ware_hex} WHERE AccountID='{$this->user}'");
  }

  private function get_serials()
  {
    $query = $this->db->query("SELECT * FROM pr_smithy WHERE memb___id='{$this->user}'");
    $data = array();
    while ($row = $this->db->FetchAssoc($query))
    {
      $data[] = $row;
    }

    return $data;
  }

  private function get_items()
  {
    $query = $this->db->query("SELECT * FROM pr_webware_items WHERE memb___id='{$this->user}'");
    $data = array();
    while ($row = $this->db->FetchAssoc($query))
    {
      $data[] = $row;
    }

    return $data;
  }


  public function return_item()
  {


    $data["item"] = array();
    $data["return_item"] = $this->option["return_item"];

    $serials = $this->get_serials();

    if (isset($_POST["return"]))
    {
      foreach ($this->get_items() as $row)
      {
        if ($row["id"] == $_POST["return"])
        {
          $serial = hexdec(substr($row["item"], 32, 8));
          foreach ($serials as $serial_data)
          {
            if ($serial_data["item_serial"] == $serial)
            {
              $this->set_volute($this->get_volute() + $serial_data["price"] / 100 * (100 - $this->option["return_item"]));
              $this->db->Query("DELETE FROM pr_webware_items WHERE id={$row["id"]}");
              $this->db->Query("DELETE FROM pr_smithy WHERE id={$serial_data["id"]}");
            }
          }
        }
      }
    }

    $data["volute"] = $this->get_volute();

    foreach ($this->get_items() as $row)
    {
      foreach ($serials as $serial_data)
      {
        if ($serial_data["item_serial"] == hexdec(substr($row["item"], 32, 8)))
        {
          $item = new Item($row["item"]);
          $data["item"][] = array(
            "id"     => $row["id"],
            "name"   => $item->getColorizedShortName(),
            "info"   => $item->getInfo(true),
            "price"  => $serial_data["price"],
            "result" => $serial_data["price"] / 100 * (100 - $this->option["return_item"])
          );
        }
      }
    }

    echo $this->parser->parse("return.html", $data, true);
  }

}