<?php
// by Profesor08
// декодирование HEX кода вещи

class ItemCore
{
  public $id;
  public $group;
  public $level;
  public $option;
  public $skill;
  public $luck;
  public $excellent;
  public $durability;
  public $sockets;
  public $serial1;
  public $serial2;
  public $harmony_type;
  public $harmony_level;
  public $pvp;
  public $bytes;
  public $ancient;
  public $excellent_options;

  public function __construct($item)
  {
    // установление значений переменных по умолчанию
    $this->init($item);
    // узнаем id вещи
    $this->id = ($item[7] >= 128 ? 256 : 0) + $item[0];

    // узнаем группу вещи
    $this->group = (int)($item[9] / 16);
    // узнаем есть ли skill
    $opt = $item[1];
    if ($opt >= 128)
    {
      $this->skill = 1;
    }
    // узнаем level
    if ($this->skill == 1)
    {
      $opt -= 128;
    }
    $this->level = (int)($opt / 8);
    // узнаем luck
    $opt = (int)($opt % 8);
    if ($opt > 3)
    {
      $this->luck = 1;
    }
    // узнаем excellent
    if ($opt > 3)
    {
      $opt -= 4;
    }
    $ex = $item[7];
    if ($ex >= 128)
    {
      $ex -= 128;
    }
    if ($ex > 63)
    {
      $ex -= 64;
      $opt += 4;
    }
    if ($ex >= 32)
    {
      $ex -= 32;
      $this->excellent += 32;
      $this->excellent_options[] = 32;
    }
    if ($ex >= 16)
    {
      $ex -= 16;
      $this->excellent += 16;
      $this->excellent_options[] = 16;
    }
    if ($ex >= 8)
    {
      $ex -= 8;
      $this->excellent += 8;
      $this->excellent_options[] = 8;
    }
    if ($ex >= 4)
    {
      $ex -= 4;
      $this->excellent += 4;
      $this->excellent_options[] = 4;
    }
    if ($ex >= 2)
    {
      $ex -= 2;
      $this->excellent += 2;
      $this->excellent_options[] = 2;
    }
    if ($ex >= 1)
    {
      $ex -= 1;
      $this->excellent += 1;
      $this->excellent_options[] = 1;
    }
    // узнаем option
    $this->option = $opt + $ex;
    // узнаем harmony
    $this->harmony_type = (int)($item[10] / 16);
    $this->harmony_level = (int)($item[10] % 16);
    if ($this->harmony_type == 15)
    {
      $this->harmony_type = 0;
    }
    if ($this->harmony_level == 15)
    {
      $this->harmony_level = 0;
    }
    // узнаем pvp
    $this->pvp = $item[9] % 16 != 0 ? true : false;
    // узнаем sockets
    $this->sockets = array_slice($item, 11, 5);
    // узнаем durability
    $this->durability = $item[2];
    // узнаем serial1
    $this->serial1 = 0;
    // узнаем serial2
    $this->serial2 = 0;
    // узнаем ancient
    $this->ancient = $item[8];
  }

  private function init($bytes)
  {
    $this->id = 0;
    $this->group = 0;
    $this->level = 0;
    $this->option = 0;
    $this->skill = 0;
    $this->luck = 0;
    $this->excellent = 0;
    $this->durability = 0;
    $this->sockets = 0;
    $this->serial1 = 0;
    $this->serial2 = 0;
    $this->harmony_type = 0;
    $this->harmony_level = 0;
    $this->pvp = 0;
    $this->ancient = 0;
    $this->excellent_options = array();
    $this->bytes = $bytes;
  }

  final public function is_socket()
  {
    foreach ($this->sockets as $socket)
    {
      if ($socket != 255)
      {
        return true;
      }
    }

    return false;
  }

  final public function is_harmony()
  {
    if ($this->harmony_type > 0)
    {
      return true;
    }

    return false;
  }

  final public function getId()
  {
    return $this->id;
  }

  final public function getGroup()
  {
    return $this->group;
  }

  final public function getLevel()
  {
    return $this->level;
  }

  final public function getOption()
  {
    return $this->option;
  }

  final public function getSkill()
  {
    return $this->skill;
  }

  final public function getLuck()
  {
    return $this->luck;
  }

  final public function getExcellent()
  {
    return $this->excellent;
  }

  final public function getDurability()
  {
    return $this->durability;
  }

  final public function getSockets()
  {
    return $this->sockets;
  }

  final public function getHarmonyType()
  {
    return $this->harmony_type;
  }

  final public function getHarmonyLevel()
  {
    return $this->harmony_level;
  }

  final public function getPvp()
  {
    return $this->pvp;
  }

  final public function getSerial1()
  {
    return $this->serial1;
  }

  final public function getSerial2()
  {
    return $this->serial2;
  }

  final public function getAncient()
  {
    return $this->ancient;
  }

  final public function getBytes()
  {
    return $this->bytes;
  }

  final public function getHex()
  {
    $result = "";
    foreach ($this->bytes as $key => $byte) 
    {
      if ($byte <= 15)
      {
        $result .= "0";
      }
      $result .= strtoupper(dechex($byte));
    }
    return $result;
  }
}
