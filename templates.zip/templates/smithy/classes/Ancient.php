<?php

/**
 * Created by PhpStorm.
 * User: Profesor08
 * Date: 28.01.2016
 * Time: 16:52
 */
class Ancient
{

  public function __construct()
  {
    $this->name = include("templates/smithy/data/ancient/option_name.php");
    $this->item_set_type = include("templates/smithy/data/ancient/item_set_type.php");
    $this->item_set_option = include("templates/smithy/data/ancient/item_set_option.php");
    $this->stats = include("templates/smithy/data/ancient/stats.php");
  }

  /**
   * @param $group - item group
   * @param $id - item id
   * @param $code - item ancient code
   * @return int
   */
  public function getSetId($group, $id, $code)
  {
    if (isset($this->item_set_type[$group][$id]))
    {
      switch ($code)
      {
        case 5:
          return $this->item_set_type[$group][$id]["TierI"];
        case 6:
          return $this->item_set_type[$group][$id]["TierII"];
        case 9:
          return $this->item_set_type[$group][$id]["TierI"];
        case 10:
          return $this->item_set_type[$group][$id]["TierII"];
      }
    }

    return -1;
  }

  public function getAdditionalStats($group, $id, $code)
  {
    if (isset($this->stats[$group][$id]))
    {
      if (count($this->stats[$group][$id]) == 1)
      {
        switch($code)
        {
          case 5: return $this->stats[$group][$id][0] . " +5";
          case 9: return $this->stats[$group][$id][0] . " +10";
        }
      }
      else
      {
        switch($code)
        {
          case 5: return $this->stats[$group][$id][0] . " +5";
          case 6: return $this->stats[$group][$id][1] . " +5";
          case 9: return $this->stats[$group][$id][0] . " +10";
          case 10: return $this->stats[$group][$id][1] . " +10";
        }
      }
    }

    return "Stats points + ??";
  }

  public function getName($group, $id, $code)
  {
    if (isset($this->item_set_option[$this->getSetId($group, $id, $code)]))
    {
      return $this->item_set_option[$this->getSetId($group, $id, $code)]["Name"];
    }
    return "Ancient";
  }

  public function getSetOptions($id)
  {
    return $this->item_set_option[$id];
  }

  public function getOptionName($id)
  {
    return $this->name[$id];
  }
  
}