<?php

/**
 * Created by PhpStorm.
 * User: Profesor08
 * Date: 16.11.2014
 * Time: 5:11
 */
class ItemOptions
{

  private $bytes;

  public function __construct($group = 0,
                              $id = 0,
                              $level = 0,
                              $option = 0,
                              $luck = 0,
                              $skill = 0,
                              $excellent = 0,
                              $durability = 0,
                              $ancient = 0,
                              $refinery = 0,
                              $harmony_type = 0,
                              $harmony_level = 0,
                              $socket1 = 255,
                              $socket2 = 255,
                              $socket3 = 255,
                              $socket4 = 255,
                              $socket5 = 255)
  {

    $this->bytes = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 255);

    if (is_array($group))
    {

      $params = array(
        "group",
        "id",
        "level",
        "option",
        "luck",
        "skill",
        "excellent",
        "durability",
        "ancient",
        "refinery",
        "harmony_type",
        "harmony_level",
        "socket1",
        "socket2",
        "socket3",
        "socket4",
        "socket5"
      );
      $tmp = $group;
      foreach ($params as $key => $name)
      {
        if (isset($tmp[$key]))
        {
          $$name = $tmp[$key];
        }
      }
    }


    // item id
    if ($id >= 256)
    {
      $this->bytes[0] = $id - 256;
      $this->bytes[7] = 128;
    }
    else
    {
      $this->bytes[0] = $id;
    }
    // item group
    $this->bytes[9] = (int)($group * 16);
    // item level
    $this->bytes[1] = $level * 8;
    // item option >= 4
    if ($option >= 4)
    {
      $this->bytes[7] += 64;
      $option -= 4;
    }
    $this->bytes[1] += $option;
    // item luck
    if ($luck > 0)
    {
      $this->bytes[1] += 4;
    }
    // item skill
    if ($skill > 0)
    {
      $this->bytes[1] += 128;
    }
    // item excellent
    $this->bytes[7] += $excellent;
    // item durability
    $this->bytes[2] = $durability;
    // item ancient
    $this->bytes[8] = $ancient;
    // item harmony
    $this->bytes[10] = $harmony_type * 16 + $harmony_level;
    // item refinery
    $this->bytes[9] += $refinery;
    // item sockets
    $this->bytes[11] = $socket1;
    $this->bytes[12] = $socket2;
    $this->bytes[13] = $socket3;
    $this->bytes[14] = $socket4;
    $this->bytes[15] = $socket5;

  }

  public function getHex()
  {
    $chars = array_map("chr", $this->bytes);
    $bin = join("", $chars);

    return strtoupper(bin2hex($bin));
  }

  public function getBytes()
  {
    return $this->bytes;
  }

}