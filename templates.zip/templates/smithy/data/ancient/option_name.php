<?php
/**
 * Created by PhpStorm.
 * User: Profesor08
 * Date: 23.01.2016
 * Time: 2:40
 */

return array(
  "0"  => "Increase Strength +%s",
  "1"  => "Increase Agility +%s",
  "2"  => "Increase Energy +%s",
  "3"  => "Increase AG +%s",
  "4"  => "Increase Command +%s",
  "5"  => "Increase Minimum damage +%s",
  "6"  => "Increase Maximum damage +%s",
  "7"  => "Increase Wizardry Damage +%s%",
  "8"  => "Increase Damage +%s",
  "9"  => "Increase Attack Rate +%s",
  "10" => "Increase Defense +%s",
  "11" => "Increase Maximum Life +%s",
  "12" => "Increases Maximum Mana +%s",
  "13" => "Increase Maximum AG +%s",
  "14" => "Increase Recovery Rate +%s",
  "15" => "Increase Critical Damage Rate +%s%",
  "16" => "Increase Critical Damage +%s",
  "17" => "Increase Excellent Damage Rate +%s",
  "18" => "Increase Excellent Damage +%s",
  "19" => "Increase Skill Damage +%s",
  "20" => "Double Damage Rate +%s%",
  "21" => "Ignore Enemy's Defense +%s%",
  "22" => "Increase Defense when using Shield weapons +%s%",
  "23" => "Increase damage when using two handed weapons +%s%"
);