<?php
/**
 * Created by PhpStorm.
 * User: Profesor08
 * Date: 23.01.2016
 * Time: 4:57
 */

return array(
  1 => 'Attack Success Rate increase',
  2 => 'Additional Damage',
  3 => 'Defense Success Rate increase',
  4 => 'Defensive Skill',
  5 => 'Max HP increase',
  6 => 'Max SD increase',
  7 => 'SD Auto Recovery',
  8 => 'SD Recovery Rate increase',
);