<?php

/**
 * Created by PhpStorm.
 * User: Profesor08
 * Date: 12.03.2016
 * Time: 5:56
 */
class SlotGame
{

  public function __construct($user, Sql $db)
  {
    $this->user = $user;
    $this->db = $db;
    $this->parser = new CI_Parser("templates/slot/view/");
    $this->config = json_decode(file_get_contents("templates/slot/config/config.json"), true);
  }

  public function index()
  {
    $data["free"] = array();
    $data["images"] = array();
    $data["volute"] = number_format($this->get_coins(), 0, "", ",");

    if ($this->check_free())
    {
      $data["free"][] = array(
        "amount" => $this->config["free"]["bet"]
      );
    }

    foreach ($this->config["images"] as $id => $image)
    {
      $data["images"][] = $image;
    }

    return $this->parser->parse("body.html", $data, true);
  }

  public function get_free_bet()
  {
    return $this->config["free"]["bet"];
  }

  public function calc_rate_data()
  {
    $data = 0;
    foreach ($this->config["images"] as $image)
    {
      $data += $image["rate"];
    }

    return $data;
  }

  private function get_number($data)
  {
    $rate = 0;
    foreach ($this->config["images"] as $id => $image)
    {
      $rate += $image["rate"];
      if ($rate >= $data)
      {
        return $id;
      }
    }

    return null;
  }

  public function get_reward($data, $bet)
  {
    $result = array();
    foreach($data as $id)
    {
      if (array_key_exists($id, $result))
      {
        $result[$id]++;
      }
      else
      {
        $result[$id] = 1;
      }
    }

    foreach($result as $id => $count)
    {
      foreach($this->config["images"][$id]["variants"] as $variant)
      {
        if ($variant["count"] == $count)
        {
          return intval($bet * $variant["multiplier"]);
        }
      }
    }

    return false;
  }

  public function get_result()
  {
    $data = array();

    $rates = $this->calc_rate_data();

    for ($i = 0; $i < 5; $i++)
    {

      $number = $this->get_number(rand(0, $rates));

      while(in_array($number, $data))
      {
        $number = $this->get_number(rand(0, $rates));
      }

      $data[] = $number;

      for($j = 0; $j < 4 && $i < 4; $j++)
      {
        if (rand(1, 100) <= $this->config["rate"][$j])
        {
          $data[] = $number;
          $i++;
        }
        else
        {
          break;
        }
      }

    }

    return $data;
  }

  public function use_free()
  {
    $this->db->Query("INSERT INTO pr_slot_free (memb___id) VALUES ('{$this->user}')");
  }

  public function check_free()
  {
    $query = $this->db->Query("SELECT TOP 1 * FROM pr_slot_free WHERE memb___id='{$this->user}' AND date > '" . date("Y-m-d 00:00:00", strtotime("-1 day")) . "'");
    while ($this->db->FetchAssoc($query))
    {
      return false;
    }

    return true;
  }

  public function check_bet($bet)
  {
    if ($bet <= $this->get_coins())
    {
      return true;
    }

    return false;
  }

  public function get_coins()
  {
    $data = $this->db->FetchAssoc($this->db->Query("SELECT credits FROM MEMB_INFO WHERE memb___id='{$this->user}'"));

    return $data["credits"];
  }

  public function extract_coins($bet)
  {
    $this->db->Query("UPDATE MEMB_INFO SET credits = credits - {$bet} WHERE memb___id='{$this->user}'");
  }

  public function add_coins($coins)
  {
    $this->db->Query("UPDATE MEMB_INFO SET credits = credits + {$coins} WHERE memb___id='{$this->user}'");
  }

}