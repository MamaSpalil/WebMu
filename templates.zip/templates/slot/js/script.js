/**
 * Created by Profesor08 on 12.03.2016.
 */

(function ()
{

  var cells = document.querySelectorAll(".slot .machine .cells_container.main_cells .cell");
  var fake = document.querySelectorAll(".slot .machine .cells_container.fake .cell");
  var bet = document.querySelector("button.bet");
  var bet_amount = document.querySelector(".bet_amount");
  var free = document.querySelector("button.free");
  var vc = document.querySelector(".volute span");
  var success = document.querySelector(".message.success");
  var fail = document.querySelector(".message.error");
  var wait = [false, false, false, false, false];
  var icons = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17];

  var rand = function (min, max)
  {
    return Math.floor(min + Math.random() * (max + 1 - min));
  };

  var shuffle = function (a)
  {
    for (var i = 0, tmp = a[i], r_index = rand(0, 17); i < a.length; i++, tmp = a[i], r_index = rand(0, 17))
    {
      a[i] = a[r_index];
      a[r_index] = tmp;
    }
  };

  var spin = function (data, callback)
  {
    [].forEach.call(cells, function (cell)
    {
      cell.classList.add("animate");
    });

    [].forEach.call(fake, function (cell)
    {
      cell.classList.add("animate");
    });

    shuffle(icons);

    setTimeout(function ()
    {

      [].forEach.call(cells, function (cell, id)
      {
        setTimeout(function ()
        {
          cell.classList.remove("animate");
          fake[id].classList.remove("animate");
          fake[id + 5].classList.remove("animate");
          cell.style.backgroundPosition = "0px " + (-data.result[id] * 100) + "px";
          fake[id].style.backgroundPosition = "0px " + (-icons[id] * 100) + "px";
          fake[id + 5].style.backgroundPosition = "0px " + (-icons[id + 5] * 100) + "px";
          wait[id] = false;
          if (wait.indexOf(true) == -1)
          {
            callback();
          }
        }, rand(500, 2000));
      });

    }, 3000);
  };

  var setState = function (state)
  {
    [].forEach.call(cells, function (cell, id)
    {
      wait[id] = state;
    });
  };

  var update_volute = function ()
  {
    $.ajax({
      url: "ajax.php?get_vc",
      dataType: "json",
      success: function (data)
      {
        if (data.error)
        {
          alert(data.error);
        }
        else
        {
          vc.innerHTML = data.result;
        }
      },
      error: function (data)
      {
        console.log(data);
      }
    });
  };

  shuffle(icons);

  [].forEach.call(cells, function (cell, id)
  {
    var y = -(rand(0, 1800) % 100 * 100) + "px";
    cell.style.backgroundPosition = "0px " + y;
  });

  [].forEach.call(fake, function (cell, id)
  {
    var y = -icons[id] * 100 + "px";
    cell.style.backgroundPosition = "0px " + y;
  });


  bet.addEventListener("click", function ()
  {
    if (wait.indexOf(true) != -1)
    {
      return;
    }

    setState(true);

    fail.classList.add("hide");
    success.classList.add("hide");

    $.ajax({
      url: "ajax.php?bet=" + bet_amount.value,
      dataType: "json",
      success: function (data)
      {
        console.log(data.result);
        if (data.error !== false)
        {
          fail.classList.remove("hide");
          fail.innerHTML = data.error;
          setState(false);
        }
        else
        {
          spin(data, function ()
          {
            if ("reward" in data)
            {
              success.classList.remove("hide");
              success.innerHTML = data.message;
            }
            else
            {
              fail.classList.remove("hide");
              fail.innerHTML = data.message;
            }
            update_volute();
          });
        }
      },
      error: function (data)
      {
        console.log(data);
        setState(false);
      }
    });

  });


  if (free)
  {
    free.addEventListener("click", function ()
    {
      if (wait.indexOf(true) != -1)
      {
        return;
      }

      setState(true);

      $.ajax({
        url: "ajax.php?free",
        dataType: "json",
        success: function (data)
        {
          if (data.error !== false)
          {
            fail.classList.remove("hide");
            fail.innerHTML = data.error;
            setState(false);
          }
          else
          {
            spin(data, function ()
            {
              if ("reward" in data)
              {
                success.classList.remove("hide");
                success.innerHTML = data.message;
              }
              else
              {
                fail.classList.remove("hide");
                fail.innerHTML = data.message;
              }
              update_volute();
            });
          }
        },
        error: function (data)
        {
          console.log(data);
          setState(false);
        }
      });

    });
  }


})();

