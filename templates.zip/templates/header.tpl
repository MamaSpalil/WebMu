<!doctype html>
<html>
<head>
    <base href="<?php echo $Web['adress']; ?>" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="<?php echo $Web['title']; ?> - Бесплатный игровой сервер многопользовательской онлайн игры MuOnline.Только у нас фулл иговым путем и много всего подобного ! Наш сервер понравиться всем понимающим людям ! Заходите и насладитесь красивой игрой! Enjoy with the best game!" />
    <meta name="keywords" content="ресет, Season 8, новости mu, новый, скачать, русский игровой сервер, launcher, квесты, му онлайн, форум, квест система, система, earthmu, mu online, lom, season, season9, earthmuo, mu" />
    <meta name="robots" content="index,follow" />
    <title><?php echo $Engine->GetCurrentModule($Web_URL[0]); ?> - <?php echo $Web['title']; ?></title>
    <link rel="shortcut icon" href="templates/images/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" type="text/css" href="templates/css/main.css"/>
    <link rel="stylesheet" type="text/css" href="templates/css/fonts.css"/>
    <!-- Стиль конец  -->
    <!-- Скрипты начало  -->
    <!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.js"></script>-->
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
    <script type="text/javascript" src="templates/js/engine.js"></script>
    <!--<script type="text/javascript" src="templates/js/events<?php if ($_COOKIE['lang'] == 'en') { echo '_en'; } ?>.js"></script>-->
    <script type="text/javascript" src="templates/js/sss.min.js"></script>
    <!--
    <link rel="stylesheet" type="text/css" href="templates/css/styles<?php if ($_COOKIE['lang'] == 'en') { echo '_en'; } ?>.css" media="all"/>
    -->
</head>
<body id="body" onkeydown="engine(event);">
<script type="text/javascript" src="templates/js/tooltip.js"></script>
<header>
    <div class="wrapper">
        <a href="index.php">
            <img src="templates/img/elements/logo.png" alt="">
        </a>
    </div>
</header>
<div class="bg-content">
    <div class="wrapper">
        <aside class="left-sitebar">
            <div class="nav-block">
                <ul>
                    <li><a href="news"><?php echo $Lang['TPL_MENU_NEWS']; ?></a></li>
                    <li><a href="top"><?php echo $Lang['TPL_MENU_TOP']; ?></a></li>
                    <li><a href="<?php echo $Web['forum']['url']; ?>" target="_blank"><?php echo $Lang['TPL_MENU_FORUM']; ?></a></li>
                    <li><a href="register"><?php echo $Lang['TPL_MENU_REG']; ?></a></li>
                    <li><a href="download"><?php echo $Lang['TPL_MENU_DOWNLOAD']; ?></a></li>
                    <li><a href="about"><?php echo $Lang['TPL_MENU_ABOUT']; ?></a></li>
                </ul>
            </div>
            <div class="block-top">
                <?php include 'core/heroes.php'; ?>

            </div>
        </aside>
        <main class="main-content">
            <a href="#" class="btn-start-game"></a>
            <div class="news-block">