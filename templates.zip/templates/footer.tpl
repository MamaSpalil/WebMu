

            </div>
        </main>
        <aside class="right-sitebar">
            <div class="block-online">
                <div class="segment-server">
                    <p>
                        <span class="online"></span>
                        Fire
                        <span class="coll-players">587</span>
                    </p>
                </div>
                <?php include 'core/online.php'; ?>
            </div>
            <div class="block-login">
                <?php if(isset($_SESSION['UserName'])) { ?>
                <div class="account_menu">
                    <a href="account"><b><?php echo $Lang['TPL_ACC_CONT']; ?></b></a>
                    <?php if ($premium_enabled[$Engine->GetServer($_SESSION["Server"])]) { ?>
                    <a href="premium" class=""><b><b style="color: orange"><?php echo $Lang["premium_title"]; ?></b></a>
                    <?php } ?>
                    <a href="premium2"><b>Премиум 2</b></a>
                    <a href="payments"><b><b style="color: green">Купить WC</b></a>

                    <a href="slot"><b><b style="color: orange"><?php echo $Lang['SLOT_LOTTERY']; ?></b></a>
                    <?php

							if (isset($_SESSION["Server"]) && in_array($_SESSION["Server"], array(0, 1)))
							{
								echo '<a href="smithy"><b><b style="color: orange">'.$Lang['TPL_ACC_SHOP'].'</b></a>';
                        }
                        else
                        {
                        echo '<a href="smithy"><b><b style="color: orange">'.$Lang['TPL_ACC_SHOP'].'</b></a>';
                        }

                        ?>

                        <a href="exchange"><b><b style="color: orange"><?php echo $Lang['TPL_ACC_EXCHANGE']; ?></b></a>
                        <a href="bank"><b><?php echo $Lang['TPL_ACC_BANK']; ?></b></a>
                        <?php if ($BuyReset['enabled'] == 1) { ?>
                        <?php } ?>
                        <a href="warehouse"><b><?php echo $Lang['WEB_WARE']; ?></b></a>
                        <a href="webmarket"><b><?php echo $Lang['WEB_MARKET']; ?></b></a>
                        <a href="move"><b>Teleport Lorencia</b></a>
                        <a href="<?php echo $Web['adress']; ?>xtremetop100.php" class="wcoin"><b><b style="color: orange">XTREME = 5 WC</span></b></a>
                        <a href="http://mu.mmotop.ru/" class="wcoin"><b><b style="color: orange">MMOTOP = 5 WC</span></b></a>
                        <!--<a href="resettree" class="wcoin"><b><?php echo $Lang["reset_tree_menu"]; ?></b></a>-->
                        <a href="stats"><b><?php echo $Lang['TPL_ACC_STATS']; ?></b></a>
                        <!--<a href="reset"><b><?php echo $Lang['TPL_ACC_RESET']; ?></b></a>-->
                        <a href="change"><b><?php echo $Lang['TPL_ACC_CLASS']; ?></b></a>
                        <a href="hide"><b><?php echo $Lang['TPL_ACC_HIDE']; ?></b></a>
                        <a href="resetstats"><b><?php echo $Lang['RESETSTATS']; ?></b></a>
                        <!--<?php if ($GrandReset['enabled']) { ?><a href="grandreset"><b><?php echo $Lang['TPL_ACC_GR']; ?></b></a><?php } ?>-->
                        <a href="changename"><b><?php echo $Lang['CHANGENAME']; ?></b></a></li>
                        <a href="changepassword"><b><?php echo $Lang['ACCOUNT_TITLE3']; ?></b></a>
                        <a href="resettree"><b>Сбросить Skill Tree</b></a>
                        <!--<a href="disconnect"><b>Дисконнект</b></a>-->
                        <?php if (in_array($_SESSION['UserName'], explode(',', $GM['account']))) echo '<b><a href="gamemaster" id="menu19" class="select" style="text-decoration: blink; color: rgb(0, 0, 250);">'.$Lang['TPL_ACC_GM'].'</a></b>'; ?>
                    <?php if (in_array($_SESSION['UserName'], explode(',', $Admin['account']))) echo '<b><a href="admin" id="menu20" class="select" style="text-decoration: blink; color: rgb(250, 0, 0);">'.$Lang['TPL_ACC_ADMIN'].'</a></b>'; ?>
                    <form action="" method="post" name="log_out"><input type="hidden" name="exit" value="1"><a href="javascript://" onclick="document.log_out.submit();" type="submit" class="submit"><b><?php echo $Lang['TPL_ACC_LOGOUT']; ?></b></a></form></li>
                </div>
                <?php } else { ?>
                <form action="" method="post" name="login">
                    <input type="text" placeholder="<?php echo $Lang['TPL_ACC_LOGIN']; ?>" class="inp-login" name="acc" id="login_input" maxlength="10">
                    <input type="password" name="pass" id="pass_input" maxlength="10" placeholder="<?php echo $Lang['TPL_ACC_PASS']; ?>" class="inp-pass">
                    <a href="#">Забыли пароль?</a>
                    <input name="login" value="login" type="hidden">
                    <input type="submit" name="login_in" class="btn-vhod" value="">
                    <div class="clear"></div>

                </form>
                <?php } ?>
            </div>
            <div class="block-topic-forum">
                <?php include 'core/rss.php'; ?>
            </div>
        </aside>
    </div>
</div>
</body>
</html>